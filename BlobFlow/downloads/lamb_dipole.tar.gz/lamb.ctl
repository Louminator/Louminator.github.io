  #asdfasfd asdf asdf adfasdf  43534523
TimeStep: 0.002
l2Tol: 3.3e-4
alpha: 0.9
MergeBudget: 1.0
MergeStep: 0.01
ClusterRadius: 0.5
Mergea2Tol: 0.1
MergeThTol: 0.1


/* MERGE.C */
/* Copyright (c) 2000 Louis F. Rossi                                    *
 * Elliptical Corrected Core Spreading Vortex Method (ECCSVM) for the   *
 * simulation/approximation of incompressible flows.                    *

 * This program is free software; you can redistribute it and/or modify *
 * it under the terms of the GNU General Public License as published by *
 * the Free Software Foundation; either version 2 of the License, or    *
 * (at your option) any later version.					*

 * This program is distributed in the hope that it will be useful,      *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of       *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *
 * GNU General Public License for more details.                         *

 * You should have received a copy of the GNU General Public License    *
 * along with this program; if not, write to the Free Software          *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 *
 * USA                                                                  *
 *                                                                      *
 * or until 15 January 2001                                             *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Massachusetts Lowell                                   *
 * One University Ave                                                   *
 * Lowell, MA 01854                                                     *
 * 
 * or after 15 January 2001                                             *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Delaware                                               *
 * Newark, DE 19715-2553                                                */

#include "global.h"

void rectify()
{
   int i;
   
   /* Make sure all the blobs are oriented so that the prefered axis is the
    * major axis. */
   
  for (i=0; i<N; ++i)
     if (blobguts[i].a2 < 1.0)
     {
	flip_blob(&(blobguts[i]));
	set_blob(&(blobguts[i]),&(tmpparms[i]));
     }
}

double searchlist(ind,indmax,relerr,maxerr)
int ind[NMax],indmax;
double relerr,maxerr;
{
   int mergelist[NMax],mergeable,i,j,k,l,gotone,best_ind;
   
   double cum_tot[6],this_tot[6],trial_tot[6],tmpa2,tmpa4,tmps2,
   a2_rescale,s2_rescale,r_rescale,relerr2,relerr3,temp,
   best_tot[6],best_err,best_relerr;
   
   mergelist[0] = ind[0];
   mergeable = 1;
   
   cum_tot[0] = mblob[ind[0]].blob0.strength;
   cum_tot[1] = 
     mblob[ind[0]].blob0.strength*mblob[ind[0]].blob0.x;
   cum_tot[2] = 
     mblob[ind[0]].blob0.strength*mblob[ind[0]].blob0.y;
   cum_tot[3] = 
     mblob[ind[0]].blob0.strength*(SQR(mblob[ind[0]].blob0.x)+
				   2.0*blobguts[ind[0]].s2*
				   (tmpparms[ind[0]].sin2/
				    blobguts[ind[0]].a2+
				    tmpparms[ind[0]].cos2*
				    blobguts[ind[0]].a2));
   cum_tot[4] = 
     mblob[ind[0]].blob0.strength*(SQR(mblob[ind[0]].blob0.y)+
				   2.0*blobguts[ind[0]].s2*
				   (tmpparms[ind[0]].cos2/
				    blobguts[ind[0]].a2+
				    tmpparms[ind[0]].sin2*
				    blobguts[ind[0]].a2));
   cum_tot[5] = 
     mblob[ind[0]].blob0.strength*(mblob[ind[0]].blob0.x*
				   mblob[ind[0]].blob0.y+
				   2.0*blobguts[ind[0]].s2*
				   tmpparms[ind[0]].sincos*
				   (blobguts[ind[0]].a2-
				    1.0/blobguts[ind[0]].a2));
   
   gotone = 1;
   relerr3 = 0.0;
   
   while (gotone==1)
     {
	gotone = 0;
	best_err = maxerr;
	
	for (j=1; j<indmax; ++j)
	  {
	     this_tot[0] = mblob[ind[j]].blob0.strength;
	     this_tot[1] = 
	       mblob[ind[j]].blob0.strength*mblob[ind[j]].blob0.x;
	     this_tot[2] = 
	       mblob[ind[j]].blob0.strength*mblob[ind[j]].blob0.y;
	     this_tot[3] = 
	       mblob[ind[j]].blob0.strength*(SQR(mblob[ind[j]].blob0.x)+
					     2.0*blobguts[ind[j]].s2*
					     (tmpparms[ind[j]].sin2/
					      blobguts[ind[j]].a2+
					      tmpparms[ind[j]].cos2*
					      blobguts[ind[j]].a2));
	     this_tot[4] = 
	       mblob[ind[j]].blob0.strength*(SQR(mblob[ind[j]].blob0.y)+
					     2.0*blobguts[ind[j]].s2*
					     (tmpparms[ind[j]].cos2/
					      blobguts[ind[j]].a2+
					      tmpparms[ind[j]].sin2*
					      blobguts[ind[j]].a2));
	     this_tot[5] = 
	       mblob[ind[j]].blob0.strength*(mblob[ind[j]].blob0.x*
					     mblob[ind[j]].blob0.y+
					     2.0*blobguts[ind[j]].s2*
					     tmpparms[ind[j]].sincos*
					     (blobguts[ind[j]].a2-
					      1.0/blobguts[ind[j]].a2));
	     
	     trial_tot[0] = cum_tot[0]+this_tot[0];
	     trial_tot[1] = (cum_tot[1]+this_tot[1])/trial_tot[0];
	     trial_tot[2] = (cum_tot[2]+this_tot[2])/trial_tot[0];
	     trial_tot[3] = 
	       (cum_tot[3]+this_tot[3])/trial_tot[0]-SQR(trial_tot[1]);
	     trial_tot[4] = 
	       (cum_tot[4]+this_tot[4])/trial_tot[0]-SQR(trial_tot[2]);
	     trial_tot[5] = 
	       (cum_tot[5]+this_tot[5])/trial_tot[0]-trial_tot[1]*trial_tot[2];
	     
	     tmpa4 = 
	       (SQR(trial_tot[3])+SQR(trial_tot[4])+2.0*SQR(trial_tot[5])+
		(trial_tot[3]+trial_tot[4])*
		sqrt(SQR(trial_tot[3]-trial_tot[4])+4.0*SQR(trial_tot[5])))/
	       (2.0*(trial_tot[3]*trial_tot[4]-SQR(trial_tot[5])));
	     
	     tmpa2 = sqrt(tmpa4);
	     
	     tmps2 = 
	       (trial_tot[3]+trial_tot[4])*tmpa2/
	       (2.0*(tmpa4+1.0));
	     
	     if ( (tmpa2 < aM2) &&
		 (tmpa2 > 1.0/aM2) &&
		 (tmps2 < l2tol) )
	       {
		  r_rescale = 0.0;
		  a2_rescale = 1.0;
		  s2_rescale = 1.0;
		  
		  for (i=0; i<mergeable; ++i)
		    {
		       temp = 
			 sqrt((SQR(trial_tot[1]-mblob[ind[i]].blob0.x) +
			       SQR(trial_tot[2]-mblob[ind[i]].blob0.y))/
			      tmps2)/2.0;
		       if (temp > r_rescale) r_rescale = temp;
		       
		       temp = blobguts[ind[i]].s2/tmps2;
		       if (temp<1.0) temp=1.0/temp;
		       if (temp > s2_rescale) s2_rescale=temp;
		       
		       temp = blobguts[ind[i]].a2/tmpa2;
		       if (temp<1.0) temp=1.0/temp;
		       if (temp > a2_rescale) a2_rescale=temp;
		    }
		  
		  relerr2 = (s2_rescale*a2_rescale - 1.0)*
		    pow(a2_rescale*SQR(s2_rescale),
			1.0/(1.0/(s2_rescale*a2_rescale)-1.0)) +
		    0.86*r_rescale;

		  if (relerr2*fabs(trial_tot[0])/2.0/l2tol < best_err)
		    {
		       best_relerr = relerr2;
		       best_err = relerr2*fabs(trial_tot[0])/2.0/l2tol;
		       best_ind = j;
		       for (l=0; l<6; ++l)
			 best_tot[l] = this_tot[l];
		       gotone = 1;
		    }
	       }
	  } /*j loop */
	if (gotone == 1)
	  {
	     relerr3 = best_relerr;
		       
	     mergelist[mergeable] = ind[best_ind];
	     ++mergeable;
		       
	     for (k=best_ind; k<indmax-1; ++k)
	       ind[k] = ind[k+1];
	     --indmax;
	     
	     for (l=0; l<6; ++l)
	       cum_tot[l] += best_tot[l];
	  }
     } /* gotone loop */
   
   if (mergeable > 1) 
     {
	/* Nullify all of the merged vortices. */
	for (j=1; j<mergeable; ++j)
	  mblob[mergelist[j]].blob0.strength = 0.0;
	
	mblob[mergelist[0]].blob0.strength = cum_tot[0];
	mblob[mergelist[0]].blob0.x        = cum_tot[1]/cum_tot[0];
	mblob[mergelist[0]].blob0.y        = cum_tot[2]/cum_tot[0];
	
	cum_tot[1] /= cum_tot[0];
	cum_tot[2] /= cum_tot[0];
	
	cum_tot[3] = cum_tot[3]/cum_tot[0]-SQR(cum_tot[1]);
	cum_tot[4] = cum_tot[4]/cum_tot[0]-SQR(cum_tot[2]);
	cum_tot[5] = cum_tot[5]/cum_tot[0]-cum_tot[1]*cum_tot[2];
	     
	tmpa4 = 
	  (SQR(cum_tot[3])+SQR(cum_tot[4])+2.0*SQR(cum_tot[5])+
	   (cum_tot[3]+cum_tot[4])*
	   sqrt(SQR(cum_tot[3]-cum_tot[4])+4.0*SQR(cum_tot[5])))/
	  (2.0*(cum_tot[3]*cum_tot[4]-SQR(cum_tot[5])));
	
	tmpa2 = sqrt(tmpa4);
	
	tmps2 = 
	  (cum_tot[3]+cum_tot[4])*tmpa2/
	  (2.0*(tmpa4+1.0));
	
	blobguts[mergelist[0]].a2       = tmpa2;
	blobguts[mergelist[0]].s2       = tmps2;
	
	if (cum_tot[3]-2.0*tmps2/tmpa2 == 0.0)
	  blobguts[mergelist[0]].th = M_PI_2;
	else
	  blobguts[mergelist[0]].th = 
	  atan(cum_tot[5]/(cum_tot[3]-2.0*tmps2/tmpa2));
	
	mblob[mergelist[0]].blob0.order    = 1;
	
	set_blob(&(blobguts[mergelist[0]]),&(tmpparms[mergelist[0]]));
	deriv_ext(&(mblob[mergelist[0]].blob0),&(tmpparms[mergelist[0]]));
	++nmerge;
	
#ifdef MERGEDIAG
	fprintf(diag_log,"<%d> ",mergeable);
#endif
     }
   else
     cum_tot[0] = 0.0;

   /* If there is no merger then there is no induced error. */
   
   return(relerr3*fabs(cum_tot[0])/2.0/l2tol);
}

double clusterlist(ind,indmax,maxerr)
int ind[NMax],indmax;
double maxerr;
{
   int clusterlist[NMax],clustersize,i,j;
   
   double scale1,scale2,dx,dy,dx_rescale,dy_rescale,budget,relerr;
   
   budget = 0.0;
   
   relerr = (aM2/SQR(alpha) - 1.0)*
     pow(aM2/SQR(SQR(alpha)),1.0/(aM2/SQR(alpha)-1.0)) +
     0.86*clusterR/SQR(alpha);

   for (i=0; i<indmax-1; ++i)
     if (mblob[ind[i]].blob0.strength != 0.0)
     {	
	clusterlist[0] = ind[i];
	clustersize = 1;
	
	scale1 = 2.0*sqrt(blobguts[ind[i]].s2*blobguts[ind[i]].a2);
	scale2 = 2.0*sqrt(blobguts[ind[i]].s2/blobguts[ind[i]].a2);
	
	for (j=i+1; j<indmax; ++j)
	  if (mblob[ind[j]].blob0.strength != 0.0)
	  {
	     dx =  tmpparms[ind[i]].costh*
	       (mblob[ind[j]].blob0.x-mblob[ind[i]].blob0.x)+
	       tmpparms[ind[i]].sinth*
	       (mblob[ind[j]].blob0.y-mblob[ind[i]].blob0.y);
	     
	     dy = -tmpparms[ind[i]].sinth*
	       (mblob[ind[j]].blob0.x-mblob[ind[i]].blob0.x)+
	       tmpparms[ind[i]].costh*
	       (mblob[ind[j]].blob0.y-mblob[ind[i]].blob0.y);
	     
	     dx_rescale = dx/scale1;
	     dy_rescale = dy/scale2;
	     
	     if ( SQR(dx_rescale)+SQR(dy_rescale) < SQR(clusterR))
	       {
		  clusterlist[clustersize] = ind[j];
		  clustersize++;
	       }
	  }
	if (clustersize > 1)
	  {
	     budget +=
	       searchlist(clusterlist,clustersize,relerr,
			  maxerr*5.0/indmax);
	  }
     }
   return(budget);
}

double posneglists(double avail_budget,int k, int l, int size)
{
   int indp[NMax],indpmax,indn[NMax],indnmax;
   
   FineGridLink *trace;
   
   double cum_error;
   
   indpmax = 0;
   indnmax = 0;
   trace = FineGridLinks[k+l*size];
   
   while (trace != NULL)
     {
	if (mblob[trace->element].blob0.strength>0.0)
	  {
		  indp[indpmax] = trace->element;
		  ++indpmax;
	  }
	else
	  if (mblob[trace->element].blob0.strength<0.0)
	  {
	     indn[indnmax] = trace->element;
	     ++indnmax;
	  }
	trace = trace->next;
     }
	
   cum_error = 0.0;
   
   if (indpmax>1) 
     cum_error = 
     clusterlist(indp,indpmax,avail_budget*indpmax/(indpmax+indnmax));
   if (indnmax>1) cum_error = 
     clusterlist(indn,indnmax,avail_budget*indnmax/(indpmax+indnmax));
   return(cum_error);
}

double calcaM2()
{
   int i;
   double temp;

   temp = 1.0;
   
   for (i=0; i<N; ++i)
     if (blobguts[i].a2 > temp) temp=blobguts[i].a2;
   
   return(temp);
}

void merge()
{
   int k,l,size;
   double cum_error,budget;
   
   rectify();
   
   aM2 = calcaM2();
   
   size = (int) (ldexp(1.0,mplevels));
   
   /*budget = merge_budget*(maxX-minX)*(maxY-minY)/SQR(size);*/
   budget = merge_budget;
   
#ifdef MERGEDIAG
   fprintf(diag_log,"Merging (time=%12.4e): ",SimTime);
#endif

   for (k=0; k<size; ++k)
     for (l=0; l<size; ++l)
       cum_error = posneglists(budget,k,l,size);
   
#ifdef MERGEDIAG
   fprintf(diag_log,"\n");
   fflush(diag_log);
#endif
}

void resort()
{
    int  i,removed;

    removed = 0;

    for (i=0; i<N; ++i)
	{
	    if (removed !=0)
	     {
		mblob[i-removed] = mblob[i];
		blobguts[i-removed] = blobguts[i];
		tmpparms[i-removed] = tmpparms[i];
	     }
	    if (mblob[i].blob0.strength == 0.0)
		++removed;
	}
    N -= removed;
}

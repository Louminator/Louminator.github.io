/* GLOBAL.H */
/* Copyright (c) 2000 Louis F. Rossi                                    *
 * Elliptical Corrected Core Spreading Vortex Method (ECCSVM) for the   *
 * simulation/approximation of incompressible flows.                    *

 * This program is free software; you can redistribute it and/or modify *
 * it under the terms of the GNU General Public License as published by *
 * the Free Software Foundation; either version 2 of the License, or    *
 * (at your option) any later version.					*

 * This program is distributed in the hope that it will be useful,      *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of       *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *
 * GNU General Public License for more details.                         *

 * You should have received a copy of the GNU General Public License    *
 * along with this program; if not, write to the Free Software          *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 *
 * USA                                                                  *
 *                                                                      *
 * or until 15 January 2001                                             *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Massachusetts Lowell                                   *
 * One University Ave                                                   *
 * Lowell, MA 01854                                                     *
 * 
 * or after 15 January 2001                                             *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Delaware                                               *
 * Newark, DE 19715-2553                                                */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <ctype.h>

#define SQR(X) ((X)*(X))
#define a2diff(X) (1.0/(X).a2-(X).a2)

#define NMax 100000   /* Maximum number of computational elements. */
#define PMax 40      /* Maximum number of multipole coefficients. */
#define LMax 7      /* Maximum number of levels of refinement in 
                        multipole summation */
#define Title 500     /* Maximum file name length */

typedef struct
{
    double x,y;
}
vector;

typedef struct
{
    double x,y;
    double strength;
    double dx,dy;
    int       order;
}
blob_external;

typedef struct
{
    double a2,s2,th;
}
blob_internal;

typedef struct
{
    double sin2,cos2,sincos,costh,sinth,du11,du12,du21;
}
blobparms;

typedef struct
{
   double du11,du12,du21;  
}
tensor;

typedef struct
{
    blob_external blob0,blob1,blob2,blob3,blob4;
}
metablob;

typedef struct
{
   double re,im;
}
complex;

typedef struct EltLink
{
   int element;
   struct EltLink *next;
}
FineGridLink;

extern FILE          *comp_log,*diag_log,*mpi_log,*trace_log;

extern int           N,oldN;
extern metablob      mblob[NMax];
extern blob_internal blobguts[NMax];
extern blobparms     tmpparms[NMax];
extern double        visc;                       /* Physical constants */
extern double        alpha,l2tol,dth_regularize; /* Numerical parameters */

/* Time integration parameters */
extern double TimeStep,PrefStep,FrameStep,EndTime,SimTime;
extern int    Frame,MaxOrder;

/*Fusion parameters */
extern double merge_budget,merge_p,merge_a2tol,merge_thtol;
extern double merge_mom3wt,merge_mom4wt,clusterR,aM2;
extern double MergeStep;
extern int    merge_estimator,nsplit,nmerge,totsplit,totmerge,MergeFrame;

/*Fast multipole variables*/
extern double       minX,maxX,minY,maxY,distX,distY;
extern complex      *Level_Ptr[LMax];
extern int          gridx[LMax][NMax], gridy[LMax][NMax], mplevels;
extern FineGridLink **FineGridLinks;
extern int          numk2;

/*Data export variables */
extern char filename[];

extern void init();
extern int  main();
extern void rectify();

extern void flip_blob();
extern void set_blob();

extern double dta2();
extern double dts2();
extern double dtT();
extern double dtth();

extern vector induced_vel();
extern tensor induced_veldev();

extern void push();
extern void ab2();
extern void ab3();
extern void ab4();
extern void am4();
extern void ab2half();
extern void ab3half();
extern void ab4half();
extern void am4half();
extern void split12();
extern void split14();

extern double searchlist_uniform(int *, int , double,int *);
extern double searchlist_distribution(int *, int, double,int *);

extern int  Set_Level();
extern void partition(int);
extern void InitFineGrid(int);
extern int  C(int,int);
extern complex cmult(complex, complex);
extern complex cpowi(complex, int);
extern void Calc_Coeffs(int, complex, complex[]);
extern void dpos_vel_fast(int);
extern void dpos_vel_exact(int);
extern void deriv_ext_fast(int);
extern void Create_Hierarchy();
extern void MP_Sum(int, int);
extern void MP_Direct(int, int);
extern void MP_Direct2(int, int);
extern void MP_Direct3(int, int);
extern void rk4internal(blob_internal*, blobparms*, double);
extern void chksplit();
extern void merge();
extern void resort();
extern void Release_Links(int);
extern void write_vorts(int);
extern void write_pmvorts(int);
extern void write_partition(int);
extern void split12(blob_external*, blob_internal*, blobparms*, blob_external*, blob_internal*, blobparms*);
extern void dpos_vel(int);
extern void reflect_X();
extern void cache_resort();
extern void vel_field();

extern void stop(int);

extern void chk_nan(int);

extern double wicked_big_vectah[NMax * 5];


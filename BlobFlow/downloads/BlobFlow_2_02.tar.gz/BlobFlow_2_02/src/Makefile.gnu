##########################################
# Makefile for eccsvm                    #
# Copyright (C) 2000 Louis F. Rossi      #
# You may distribute this under the      #
# terms of the GNU Public License        #
# included in this package.              #
##########################################

ifeq ($(mpi),on)
CC	= hcc
LN	= hcc
MPICFLAGS  = -DMULTIPROC
LAMLIB	= -lmpi
else
CC	= gcc
LN	= gcc
LAMLIB	=
endif

ifeq ($(xantisymm),on) 
XANTISYMMCFLAGS  = -DXANTISYMM
endif

# The two trace flags add a fair amount of disk writes
#ifeq ($(trace),low)
#TRACEFLAGS = -DTRACE
#endif

#ifeq ($(trace),hi)
#TRACEFLAGS = -DTRACE -DTRACEALL
#endif

#CFLAGS = -fast $(MPICFLAGS) $(XANTISYMMCFLAGS) $(TRACEFLAGS) $(SCHFLAG)
CFLAGS = -O3 -Wall $(MPICFLAGS) $(XANTISYMMCFLAGS) $(TRACEFLAGS) $(SCHFLAG)

# CFLAGS	= -fast
CPROF_FLAGS = -pg -g3

# CLIBS = -lm -lblas -llapack
# CLIBS = -lm -llapack -lblas -lfor
CLIBS = -lm 

OBJECTS = deriv.o evolve.o files.o flip.o init.o \
	merge.o removal.o solve.o split.o veldev.o \
	velocity.o partition.o mpsum.o mpcoeffs.o \
	reflect.o master-slave.o peer.o cache_resort.o

eflow: $(OBJECTS)
	$(LN) $(CPROF_FLAGS) -o eflow $(OBJECTS) $(CLIBS) $(LAMLIB)

$(OBJECTS): global.h multiproc.h 

.c.o:
	$(CC) -c $(CFLAGS) $(CPROF_FLAGS) $<

clean:
	rm -f *.o a.out core 

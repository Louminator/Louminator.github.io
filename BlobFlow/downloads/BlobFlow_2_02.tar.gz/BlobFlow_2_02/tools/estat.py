#!/opt/sfw/bin/python

from Tkinter import *
from string import split,atof,atoi
from regex import search
from os import system
from sys import argv
from math import fabs,sqrt,pow

class estat_front:
    
    def __init__(self,master):

	frame = Frame(master)

	self.filename1_label = Label(frame,text="Base file name:")
	self.filename1_label.grid(row=0,column=0,sticky=W)

        self.filename1_entry = StringVar()
	self.filename1_entry = Entry(frame)
	self.filename1_entry.grid(row=0,column=1)

	self.start_label = Label(frame,text="Start index:")
	self.start_label.grid(row=0,column=2,sticky=W)

	self.start_entry = Entry(frame)
	self.start_entry.grid(row=0,column=3)

	self.stop_label = Label(frame,text="Stop index:")
	self.stop_label.grid(row=1,column=2,sticky=W)

	self.stop_entry = Entry(frame)
	self.stop_entry.grid(row=1,column=3)

	self.stride_label = Label(frame,text="Stride:")
	self.stride_label.grid(row=2,column=2,sticky=W)

	self.stride_entry = Entry(frame)
	self.stride_entry.grid(row=2,column=3)

	self.button = Button(frame,text="Calculate",fg="green", \
	command=self.calculate)
	self.button.grid(row=5,column=0)

	self.button = Button(frame,text="Quit",fg="red",command=frame.quit)
	self.button.grid(row=5,column=1)

        self.start_entry.insert(END,"0");
        self.stop_entry.insert(END,"0");
        self.stride_entry.insert(END,"1");
        if (len(argv) > 1):
            self.filename1_entry.insert(END,argv[1])
        if (len(argv) > 2):
            self.filename2_entry.insert(END,argv[2])


	frame.pack()

    def stat(self,filename1):

	file1 = open(filename1)
	strs1 = split(file1.read())
	file1.close()
	
	data1 = map(atof, strs1)

        a2avg = 0.0
        s2avg = 0.0
        circ  = 0.0

        for i in range(0,len(data1),6):
            s2avg = s2avg + fabs(data1[i+2])*data1[i+3]
            a2avg = a2avg + fabs(data1[i+2])*data1[i+4]
            circ  = circ + fabs(data1[i+2])

        s2avg = s2avg/circ
        a2avg = a2avg/circ

	return (s2avg,a2avg)


    def calculate(self):
	start = atoi(self.start_entry.get())
	stop = atoi(self.stop_entry.get())
	stride = atoi(self.stride_entry.get())
        
        file4 = open(self.filename1_entry.get()+"_estat.dat","w")

	for num in range(start,stop+1,stride):
	    numstr = "%04d" % num
            filename1 = self.filename1_entry.get()+numstr+".vtx"
            
	    try:
		f = open(filename1,"r")
		f.close()

                s2stat,a2stat = self.stat(filename1)

                file4.write("%d %12.4e %12.4e\n" % \
                            (num,s2stat,a2stat))
            except IOError:
		print "File not present: "+filename1
                
        file4.close()
            
root = Tk()

root.title("estat")
app = estat_front(root)

root.mainloop()

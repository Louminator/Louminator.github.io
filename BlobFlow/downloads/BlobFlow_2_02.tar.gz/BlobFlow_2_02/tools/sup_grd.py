#!/opt/sfw/bin/python

from string import split,atof
from math import fabs
from sys import argv

class sup_grd:

    def __init__(self):
	if (len(argv) != 3):
	    print "Whoa, Hombre.  I need two file names."
	else:
	    self.sup(argv[1],argv[2])

    def sup(self,filename1,filename2):
	file1 = open(filename1)
	file2 = open(filename2)
	file3 = open("error.grd","w")
	
	strs1 = split(file1.read())
	strs2 = split(file2.read())
	
	file1.close()
	file2.close()
	
	data1 = map(atof, strs1)
	data2 = map(atof, strs2)
	
	maxw = max([max(map(fabs,data1)),max(map(fabs,data2))])
	maxwerr = 0.0
	
	for i in range(0,len(data1)-1):
	    if (fabs(data1[i]-data2[i]) > maxwerr):
		maxwerr = fabs(data1[i]-data2[i])
	    file3.write("%12.4e\n" % (data1[i]-data2[i]))

	file3.close()

	print "Absolute maximum vorticity: %10.4e" % maxw
	print "Absolute sup error: %10.4e" % maxwerr
	print "Relative sup error: %10.4e" % (maxwerr/maxw)

	return (maxw,maxwerr)
		
sup_grd()

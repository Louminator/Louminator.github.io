function w = vortpos(name,fileno,figno)

if (nargin == 2)
  figno  = fileno;
end

[fid,message] = fopen('egrid.default','r');
if fid == -1
disp(message)
end

grdname = sprintf('%s%04d.grd',name,fileno);
vtxname = sprintf('%s%04d.vtx',name,fileno);

xmin = fscanf(fid,'%lf',1);
ymin = fscanf(fid,'%lf',1);
xmax = fscanf(fid,'%lf',1);
ymax = fscanf(fid,'%lf',1);
n    = fscanf(fid,'%d',1);

fclose(fid);

[fid,message] = fopen(grdname,'r');
if fid == -1
disp(message)
end

for i = 1:n
tmp(:,i) = fscanf(fid,'%lf',n);
end
fclose(fid);
w = tmp.';

[fid,message] = fopen(vtxname,'r');
if fid == -1
disp(message);
end
  
[vtxdata,nvtx] = fscanf(fid,'%lf',[6 100000]);
nvtx = nvtx/6;

fclose(fid);

[xa,ya] = meshgrid(xmin:(xmax-xmin)/(n-1):xmax,ymin:(ymax-ymin)/(n-1):ymax);

minw = min(min(w));
maxw = max(max(w));

levels = minw:(maxw-minw)/19:maxw;

disp('Levels');
disp(levels);

figure(figno);

vort = subplot(1,2,1);

contourf(xa,ya,w,levels);

pos = subplot(1,2,2);

contour(xa,ya,w,levels);

hold on;

for i=1:nvtx
  xtmp1 = [vtxdata(1,i)-sqrt(vtxdata(4,i)*vtxdata(5,i))*cos(vtxdata(6,i)),
vtxdata(1,i)+sqrt(vtxdata(4,i)*vtxdata(5,i))*cos(vtxdata(6,i))];
  ytmp1 = [vtxdata(2,i)-sqrt(vtxdata(4,i)*vtxdata(5,i))*sin(vtxdata(6,i)),
vtxdata(2,i)+sqrt(vtxdata(4,i)*vtxdata(5,i))*sin(vtxdata(6,i))];
  xtmp2 = [vtxdata(1,i)-sqrt(vtxdata(4,i)/vtxdata(5,i))*cos(vtxdata(6,i)+pi/2),
vtxdata(1,i)+sqrt(vtxdata(4,i)/vtxdata(5,i))*cos(vtxdata(6,i)+pi/2)];
  ytmp2 = [vtxdata(2,i)-sqrt(vtxdata(4,i)/vtxdata(5,i))*sin(vtxdata(6,i)+pi/2),
vtxdata(2,i)+sqrt(vtxdata(4,i)/vtxdata(5,i))*sin(vtxdata(6,i)+pi/2)];
  ztmp1 = [vtxdata(3,i),vtxdata(3,i)];
if vtxdata(3,i) < 0.0
  line('XData',xtmp1,'YData',ytmp1,'ZData',ztmp1,'Color',[1.0 0.0 0.0]);
  line('XData',xtmp2,'YData',ytmp2,'ZData',ztmp1,'Color',[0.9 0.0 0.0]);
else
  line('XData',xtmp1,'YData',ytmp1,'ZData',ztmp1,'Color',[0.0 0.0 0.5+0.5*mod(i,10)/10]);
  line('XData',xtmp2,'YData',ytmp2,'ZData',ztmp1,'Color',[0.0 0.0 0.5+0.5*mod(i,10)/10]);
end
end
hold off;

set(vort,'XLim',[xmin xmax]);
set(vort,'YLim',[ymin ymax]);
set(pos,'XLim',[xmin xmax]);
set(pos,'YLim',[ymin ymax]);

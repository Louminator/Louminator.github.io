/* INIT-MS.C */
/* Copyright (c) 2000 Louis F. Rossi                                    *
 * A little utility to convert .vtx files to velocity fields for        *
 * Elliptical Corrected Core Spreading Vortex Method (ECCSVM) for the   *
 * simulation/approximation of incompressible flows.                    *

 * This program is free software; you can redistribute it and/or modify *
 * it under the terms of the GNU General Public License as published by *
 * the Free Software Foundation; either version 2 of the License, or    *
 * (at your option) any later version.					*

 * This program is distributed in the hope that it will be useful,      *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of       *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *
 * GNU General Public License for more details.                         *

 * You should have received a copy of the GNU General Public License    *
 * along with this program; if not, write to the Free Software          *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 *
 * USA                                                                  *
 *                                                                      *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Delaware                                               *
 * Newark, DE 19715-2553                                                */

#include <math.h>
#include <stdio.h>
#include <string.h>

#define  SQR(X) ((X) * (X))

#define  Title  160
#define  NMax   100000

typedef struct
{
    double x,y;
}
vector;

typedef struct
{
    double x,y;
    double strength;
    double dx,dy;
}
blob_external;

typedef struct
{
    double a2,s2,th;
}
blob_internal;

typedef struct
{
    double sin2,cos2,sincos,costh,sinth,du11,du12,du21;
}
blobparms;

typedef struct
{
   double du11,du12,du21;  
}
tensor;

typedef struct
{
    blob_external blob0,blob1,blob2,blob3,blob4;
}
metablob;

int  grid,i,j,N,k,quiet=0,xanti=0;
char filename[Title],gridname[Title];
double field,xbegin,xend,ybegin,yend,xstep,ystep;
blob_external blob[NMax];
blob_internal blobguts[NMax];
blobparms tmpparms[NMax];

void set_blob(the_blobguts,parms)
blob_internal *the_blobguts;
blobparms *parms;
{
    (*parms).costh = cos((*the_blobguts).th);
    (*parms).sinth = sin((*the_blobguts).th);
    (*parms).cos2 = SQR((*parms).costh);
    (*parms).sin2 = SQR((*parms).sinth);
    (*parms).sincos = (*parms).sinth*(*parms).costh;
}

init()
{
   int  dummy;
   FILE *datafile,*deffile,*fopen();
   
   N = 0;
   strcpy(gridname,filename);
   if ( (filename[strlen(filename)-3] == 'v') &&
       (filename[strlen(filename)-2] == 't') &&
       (filename[strlen(filename)-1] == 'x') )
     {
	gridname[strlen(gridname)-3] = 'g';
	gridname[strlen(gridname)-2] = 'r';
	gridname[strlen(gridname)-1] = 'd';
     }
   else
     {    
	strcat(gridname,".vel");
	strcat(filename,".vtx");
     }
   
   if ((deffile = fopen("egrid.default","r")) == NULL)
     {
	printf("No defaults file found.\n");
	printf("Lower left: ");
	scanf("%lf %lf",&xbegin,&ybegin);
	printf("Upper right: ");
	scanf("%lf %lf",&xend,&yend);
	printf("Grid size: ");
	scanf("%d",&grid);
     }
   else
     {
	fscanf(deffile,"%lf %lf",&xbegin,&ybegin);
	fscanf(deffile,"%lf %lf",&xend,&yend);
	fscanf(deffile,"%d",&grid);
	fclose(deffile);
	if (!quiet)
	  {
	     printf("Using egrid defaults file for parameters...\n");
	     printf("Lower left: (%lf,%lf)\n",xbegin,ybegin);
	     printf("Upper right: (%lf,%lf)\n",xend,yend);
	     printf("Grid: %d\n",grid);
	  }
     }

  xstep=(xend-xbegin)/(grid-1.0);
  ystep=(yend-ybegin)/(grid-1.0);

  datafile = fopen(filename,"r");
  while (!feof(datafile))
    {
      fscanf(datafile,"%lf%lf%lf%lf%lf%lf",
	     &blob[N].x,
	     &blob[N].y,
	     &blob[N].strength,&blobguts[N].s2,
	     &blobguts[N].a2,&blobguts[N].th);
	
      ++N;
      set_blob(&(blobguts[N]),&(tmpparms[N]));
    }
  --N;
   
  fclose(datafile);
}

vector induced_vel(the_blob,the_blobguts,parms,tmpdx,tmpdy,r,t,even,odd)
blob_external *the_blob;
blob_internal *the_blobguts;
blobparms *parms;
double tmpdx,tmpdy;
double r[5],t[5];
double even[5],odd[5];
{
   double eps,dx,dy;
   double c0,c1,c2,c3,c4;
   double s2,s4,s6,s8,s10;
   
   double tempu,tempv;
   
   vector result;
   
   /* Change bases to the local axes. */
   
   dx =  (*parms).costh*tmpdx+(*parms).sinth*tmpdy;
   
   dy = -(*parms).sinth*tmpdx+(*parms).costh*tmpdy;
   
   eps = (sqrt((*the_blobguts).a2)-1.0)/(sqrt((*the_blobguts).a2)+1.0);
   
   s2 = (*the_blobguts).s2;
   s4 = SQR(s2);
   s6 = s2*s4;
   s8 = s4*s4;
   s10 = s4*s6;
   
   r[0] = SQR(dx*(1-eps)/(1+eps))+SQR(dy*(1+eps)/(1-eps));
   t[0] = (SQR(dx*(1-eps)/(1+eps))-SQR(dy*(1+eps)/(1-eps)))/r[0];
   
   r[1] = SQR(r[0]);
   t[1] = SQR(t[0]);
   
   r[2] = r[1]*r[0];
   t[2] = t[1]*t[0];

   r[3] = SQR(r[1]);
   t[3] = SQR(t[1]);
   
   r[4] = r[2]*r[1];
   t[4] = t[2]*t[1];
   
   
   even[4] = (224.0-2688.0*t[1]+3584.0*t[3]);
   odd[4] =  (896.0*t[0]-1792.0*t[2]);
   
   even[3] = eps*(-640.0+7040.0*t[1]-8960.0*t[3])-160.0*t[0]+320.0*t[2];
   odd[3]  = eps*(-1920.0*t[0]+3840.0*t[2])+40.0-160.0*t[1];
   
   even[2] = SQR(eps)*(656.0-6464.0*t[1]+7680.0*t[3])+
     eps*(352.0*t[0]-640.0*t[2])-8.0+32.0*t[1];
   odd[2]  = SQR(eps)*(1312.0*t[0]-2560.0*t[2])+
     eps*(-64.0+256.0*t[1])-16.0*t[0];
   
   even[1] = SQR(eps)*eps*(-288.0+2400.0*t[1]-2560.0*t[3])+
     SQR(eps)*(-244.0*t[0]+384.0*t[2])+
     eps*(16.0-48.0*t[1])+4.0*t[0];
   odd[1]  = SQR(eps)*eps*(-288.0*t[0]+512.0*t[2])+
     SQR(eps)*(26.0-96.0*t[1])+
     eps*16.0*t[0]-2.0;
   
   even[0] = SQR(eps)*SQR(eps)*(48.0-288.0*t[1]+256.0*t[3])+
     SQR(eps)*eps*(52.0*t[0]-64.0*t[2])+
     SQR(eps)*(-8.0+16.0*t[1])-eps*4.0*t[0]+1.0;
   odd[0] = 0.0;
   

   
   c4 = SQR(SQR(eps))*(even[4]+odd[4])/r[4];
   c3 = SQR(eps)*eps*(even[3]+odd[3])/r[3];
   c2 = SQR(eps)*(even[2]+odd[2])/r[2];
   c1 = eps*(even[1]+odd[1])/r[1];
   c0 = (even[0]+odd[0])/r[0];
   
   if (r[0]/s2<0.009)
     tempv = (dx/2.0)*((*the_blob).strength/(2.0*s2))*
     2.0*(0.5-eps+eps*SQR(eps))*exp(-r[0]/(4.0*s2));
   else
     tempv = -(dx/2.0)*((*the_blob).strength/(2.0*s2))*
     ((r[0]*((c0+s2*(8.0*c1+s2*(96.0*c2+s2*(1536.0*c3+30720.0*c4*s2))))+
	    r[0]*((c1+s2*(12.0*c2+s2*(192.0*c3+3840.0*c4*s2)))+
		 r[0]*((c2+s2*(16.0*c3+320.0*c4*s2))+
		       r[0]*((c3+20.0*c4*s2)+
			    c4*r[0]))))-
	2.0*(0.5-eps+eps*SQR(eps)))*exp(-r[0]/(4.0*s2))+
       (-s2)*(4.0*c0+s2*(32.0*c1+s2*(384.0*c2+s2*(6144.0*c3+s2*122880.0*c4))))*
       (1-exp(-r[0]/(4.0*s2))));

   c4 = SQR(SQR(eps))*(even[4]-odd[4])/r[4];
   c3 = SQR(eps)*eps*(even[3]-odd[3])/r[3];
   c2 = SQR(eps)*(even[2]-odd[2])/r[2];
   c1 = eps*(even[1]-odd[1])/r[1];
   c0 = (even[0]-odd[0])/r[0];
   
  if (r[0]/s2<0.009)
    tempu = -(dy/2.0)*((*the_blob).strength/(2.0*s2))*
      2.0*(0.5+eps-eps*SQR(eps))*exp(-r[0]/(4.0*s2));
  else
    tempu = (dy/2.0)*((*the_blob).strength/(2.0*s2))*
      ((r[0]*((c0+s2*(8.0*c1+s2*(96.0*c2+s2*(1536.0*c3+30720.0*c4*s2))))+
	     r[0]*((c1+s2*(12.0*c2+s2*(192.0*c3+3840.0*c4*s2)))+
		  r[0]*((c2+s2*(16.0*c3+320.0*c4*s2))+
		       r[0]*((c3+20.0*c4*s2)+
			    c4*r[0]))))-
	2.0*(0.5+eps-eps*SQR(eps)))*exp(-r[0]/(4.0*s2))+
       (-s2)*(4.0*c0+s2*(32.0*c1+s2*(384.0*c2+s2*(6144.0*c3+s2*122880.0*c4))))*
       (1-exp(-r[0]/(4.0*s2))));

   /* Rotate back to the global axes. */
   
   result.x = ((*parms).costh*tempu-(*parms).sinth*tempv);
   result.y = ((*parms).sinth*tempu+(*parms).costh*tempv);
   
   return(result);
}

void dpos_vel(x,y,velx,vely)
double x,y,*velx,*vely;
{
   int i;
   double dx,dy,eps;
   double r[5],t[5],even[5],odd[5];
   vector v;
   tensor a;
   blobparms flipparms;
   blob_internal flipguts;
   blob_external flipblob;
   
   
   *velx = 0.0;
   *vely = 0.0;

   for (i=0; i<N; ++i)
     {
	dx = x-blob[i].x;
	dy = y-blob[i].y;

	if ( (dx != 0.0) || (dy != 0.0) )
	  {
	     v = induced_vel(&(blob[i]),&(blobguts[i]),
			     &(tmpparms[i]),dx,dy,
			     r,t,even,odd);
	     *velx += v.x;
	     *vely += v.y;

	  }
	if (xanti==1)
	  {
	    flipblob = blob[i];
	    flipguts = blobguts[i];
	    flipparms = tmpparms[i];

	    flipblob.y = - flipblob.y;
	    flipblob.strength = -flipblob.strength;
	    flipguts.th = -flipguts.th;
	    set_blob(&flipguts,&flipparms);
	  }
	dx = x-flipblob.x;
	dy = y-flipblob.y;

	if ( (dx != 0.0) || (dy != 0.0) )
	  {
	     v = induced_vel(&flipblob,&flipguts,
			     &flipparms,dx,dy,
			     r,t,even,odd);
	     *velx += v.x;
	     *vely += v.y;
	  }
     }

}

main(int argc, char *argv[])
{
   double dx,dy,c2,s2,c,s;
   FILE *outfile,*fopen();
   
   quiet = 0;
   
   if (argc > 1)
     {
	for (i=1; i<argc; ++i)
	  {
	     if (strcmp(argv[i],"-q") == 0)
	       quiet = 1;
	     if (strcmp(argv[i],"-x") == 0)
	       xanti = 1;
	     if (memcmp("-",argv[i],1) != 0)
	       strcpy(filename,argv[i]);
	  }
	
	init();
	
	outfile = fopen(gridname,"w");
	
	for (j=0; j<grid; ++j)
	  {
	     
	     if (!quiet) printf("Row %d...\n",j);
	     
	     for (i=0; i<grid; ++i)
	       {
		 dpos_vel(xbegin + i*xstep,ybegin + j*ystep,&dx,&dy);
		  fprintf(outfile,"%14.8e %14.8e\n",dx,dy);
	       }
	  }
     }
}

#!/opt/sfw/bin/python

from Tkinter import *
from string import split,atof,atoi
from regex import search
from os import system
from sys import argv

class egrid_front:
    
    def __init__(self,master):

	frame = Frame(master)

	self.filename_label = Label(frame,text="Base file name:")
	self.filename_label.grid(row=0,column=0,sticky=W)

        self.filename_entry = StringVar()
	self.filename_entry = Entry(frame)
	self.filename_entry.grid(row=0,column=1)

	self.start_label = Label(frame,text="Start index:")
	self.start_label.grid(row=0,column=2,sticky=W)

	self.start_entry = Entry(frame)
	self.start_entry.grid(row=0,column=3)

	self.stop_label = Label(frame,text="Stop index:")
	self.stop_label.grid(row=1,column=2,sticky=W)

	self.stop_entry = Entry(frame)
	self.stop_entry.grid(row=1,column=3)

	self.stride_label = Label(frame,text="Stride:")
	self.stride_label.grid(row=2,column=2,sticky=W)

	self.stride_entry = Entry(frame)
	self.stride_entry.grid(row=2,column=3)

	self.button = Button(frame,text="Count",fg="green", \
	command=self.count)
	self.button.grid(row=5,column=0)

	self.button = Button(frame,text="Quit",fg="red",command=frame.quit)
	self.button.grid(row=5,column=1)

        self.start_entry.insert(END,"0");
        self.stop_entry.insert(END,"0");
        self.stride_entry.insert(END,"1");
        if (len(argv) == 2):
            self.filename_entry.insert(END,argv[1])


	frame.pack()

    def count(self):
	start = atoi(self.start_entry.get())
	stop = atoi(self.stop_entry.get())
	stride = atoi(self.stride_entry.get())

        sizefile = open('size.dat','w')
        
	for num in range(start,stop+1,stride):
	    numstr = "%04d" % num
	    filename = self.filename_entry.get() + numstr + ".vtx"

	    try:
		f = open(filename,"r")
                txt = f.read()
		f.close()
                num = len(split(txt,"\n"))-1
                sizefile.write(str(num)+'\n')
	    except IOError:
		print "File not present: " + filename

        sizefile.close()

root = Tk()

root.title("size")
app = egrid_front(root)

root.mainloop()

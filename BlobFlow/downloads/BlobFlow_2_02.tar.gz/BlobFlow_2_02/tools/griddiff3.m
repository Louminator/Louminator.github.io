function griddiff(name1,name2)

[fid,message] = fopen('egrid.default','r');
if fid == -1
disp(message)
end

xmin = fscanf(fid,'%lf',1);
ymin = fscanf(fid,'%lf',1);
xmax = fscanf(fid,'%lf',1);
ymax = fscanf(fid,'%lf',1);
n    = fscanf(fid,'%d',1);

fclose(fid);

[fid,message] = fopen(name1,'r');
if fid == -1
disp(message)
end

for i = 1:n
tmp(:,i) = fscanf(fid,'%lf',n);
end
fclose(fid);
w1 = tmp;

[fid,message] = fopen(name2,'r');
if fid == -1
disp(message)
end

for i = 1:n
tmp(:,i) = fscanf(fid,'%lf',n);
end
fclose(fid);
w2 = tmp;

figure;

subplot(2,2,1);

contourf(w1);

subplot(2,2,2);

contourf(w2);

subplot(2,2,3);

surf(w2);

subplot(2,2,4);

surf(w1-w2);

l2err = 0.0;

werr = w1-w2;

for i=1:n
    l2err = l2err + werr(:,i)' * werr(:,i);
end

str = ['sup norm: ' num2str(max(max(abs(w1-w2))),6) ... 
        ' l2err:' num2str(sqrt(l2err),6)];
disp(str);


#!/opt/sfw/bin/python

from Tkinter import *
from string import split,atof,atoi
from regex import search
from os import system
from sys import argv
from math import fabs,sqrt,pow

class merge_err_front:
    
    def __init__(self,master):

	frame = Frame(master)

	self.filename1_label = Label(frame,text="Base file name 1:")
	self.filename1_label.grid(row=0,column=0,sticky=W)

        self.filename1_entry = StringVar()
	self.filename1_entry = Entry(frame)
	self.filename1_entry.grid(row=0,column=1)

	self.filename2_label = Label(frame,text="Base file name 2:")
	self.filename2_label.grid(row=1,column=0,sticky=W)

        self.filename2_entry = StringVar()
	self.filename2_entry = Entry(frame)
	self.filename2_entry.grid(row=1,column=1)

	self.start_label = Label(frame,text="Start index:")
	self.start_label.grid(row=0,column=2,sticky=W)

	self.start_entry = Entry(frame)
	self.start_entry.grid(row=0,column=3)

	self.stop_label = Label(frame,text="Stop index:")
	self.stop_label.grid(row=1,column=2,sticky=W)

	self.stop_entry = Entry(frame)
	self.stop_entry.grid(row=1,column=3)

	self.stride_label = Label(frame,text="Stride:")
	self.stride_label.grid(row=2,column=2,sticky=W)

	self.stride_entry = Entry(frame)
	self.stride_entry.grid(row=2,column=3)

	self.fieldcalc = IntVar()
	self.fieldcalc.set(1)
	self.cb = Checkbutton(frame,text="err field",variable=self.fieldcalc, \
	onvalue=1,offvalue=0)
	self.cb.grid(row=4,column=0,sticky=W)

	self.button = Button(frame,text="Calculate",fg="green", \
	command=self.project)
	self.button.grid(row=5,column=0)

	self.button = Button(frame,text="Quit",fg="red",command=frame.quit)
	self.button.grid(row=5,column=1)

        self.start_entry.insert(END,"0");
        self.stop_entry.insert(END,"0");
        self.stride_entry.insert(END,"1");
        if (len(argv) > 1):
            self.filename1_entry.insert(END,argv[1])
        if (len(argv) > 2):
            self.filename2_entry.insert(END,argv[2])


	frame.pack()

    def sup(self,filename1,filename2,filename3):

	file1 = open(filename1)
	file2 = open(filename2)
	
	strs1 = split(file1.read())
	strs2 = split(file2.read())
	
	file1.close()
	file2.close()
	
	data1 = map(atof, strs1)
	data2 = map(atof, strs2)
	
	maxw = max([max(map(fabs,data1)),max(map(fabs,data2))])
	maxwerr = 0.0
        l2werr = 0.0

        if self.fieldcalc.get() == 1:	
            file3 = open(filename3,"w")
            for i in range(0,len(data1)-1):
                if (fabs(data1[i]-data2[i]) > maxwerr):
                    maxwerr = fabs(data1[i]-data2[i])
                    file3.write("%12.4e\n" % (data1[i]-data2[i]))
                l2werr = l2werr + pow(data1[i]-data2[i],2)
            file3.close()
        else:
            for i in range(0,len(data1)-1):
                if (fabs(data1[i]-data2[i]) > maxwerr):
                    maxwerr = fabs(data1[i]-data2[i])
                l2werr = l2werr + pow(data1[i]-data2[i],2)

#	print "Absolute maximum vorticity: %10.4e" % maxw
#	print "Absolute sup error: %10.4e" % maxwerr
#	print "Relative sup error: %10.4e" % (maxwerr/maxw)

	return (maxw,l2werr,maxwerr)


    def project(self):
	start = atoi(self.start_entry.get())
	stop = atoi(self.stop_entry.get())
	stride = atoi(self.stride_entry.get())
        
        file4 = open(self.filename1_entry.get()+"_err.dat","w")

	for num in range(start,stop+1,stride):
	    numstr = "%04d" % num
            filename1 = self.filename1_entry.get()+numstr+".grd"
            filename2 = self.filename2_entry.get()+numstr+".grd"
            
	    try:
		f = open(filename1,"r")
		f.close()
                try:
                    f = open(filename2,"r")
                    f.close()
                except IOError:
                    print "File not present: "+filename2

                filename3 = self.filename1_entry.get()+"_err"+numstr+".grd"

                maxw,l2werr,maxerrw = self.sup(filename1,filename2,filename3)

                file4.write("%d %12.4e %12.4e %12.4e\n" % \
                            (num,maxw,sqrt(l2werr),maxerrw))
            except IOError:
		print "File not present: "+filename1
                
        file4.close()
            
root = Tk()

root.title("merge_err")
app = merge_err_front(root)

root.mainloop()

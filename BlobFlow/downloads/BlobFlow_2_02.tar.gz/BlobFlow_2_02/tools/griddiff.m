function griddiff(name1,name2)

[fid,message] = fopen('egrid.default','r');
if fid == -1
disp(message)
end

xmin = fscanf(fid,'%lf',1);
ymin = fscanf(fid,'%lf',1);
xmax = fscanf(fid,'%lf',1);
ymax = fscanf(fid,'%lf',1);
n    = fscanf(fid,'%d',1);

fclose(fid);

[fid,message] = fopen(name1,'r');
if fid == -1
disp(message)
end

for i = 1:n
tmp(:,i) = fscanf(fid,'%lf',n);
end
fclose(fid);
w1 = tmp.';

[fid,message] = fopen(name2,'r');
if fid == -1
disp(message)
end

for i = 1:n
tmp(:,i) = fscanf(fid,'%lf',n);
end
fclose(fid);
w2 = tmp.';

disp(max(max(abs(w1-w2))))

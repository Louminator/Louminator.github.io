/* MPCOEFFS.C */
/* Copyright (c) 2000 Louis F. Rossi                                    *
 * Elliptical Corrected Core Spreading Vortex Method (ECCSVM) for the   *
 * simulation/approximation of incompressible flows.                    *

 * This program is free software; you can redistribute it and/or modify *
 * it under the terms of the GNU General Public License as published by *
 * the Free Software Foundation; either version 2 of the License, or    *
 * (at your option) any later version.					*

 * This program is distributed in the hope that it will be useful,      *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of       *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *
 * GNU General Public License for more details.                         *

 * You should have received a copy of the GNU General Public License    *
 * along with this program; if not, write to the Free Software          *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 *
 * USA                                                                  *
 *                                                                      *
 * or until 15 January 2001                                             *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Massachusetts Lowell                                   *
 * One University Ave                                                   *
 * Lowell, MA 01854                                                     *
 * 
 * or after 15 January 2001                                             *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Delaware                                               *
 * Newark, DE 19715-2553                                                */

#include "global.h"

void Calc_Coeffs(int vort, complex z, complex mp[])
{
   double Gamma,a2,s2,dx,dy;
   int    i;
   
   Gamma = mblob[vort].blob0.strength;
   a2 = blobguts[vort].a2;
   s2 = blobguts[vort].s2;
   
   dx = z.re;
   dy = z.im;

   mp[0].re = 0.0;
   mp[0].im = -Gamma;
    
   mp[1].re = -(Gamma)*dy;
   mp[1].im = (Gamma)*dx;
   
   for (i=2; i<PMax; ++i)
     {
	mp[i].re = -dx*mp[i-1].re + dy*mp[i-1].im +
	  2.0*s2*(i-1)*(a2-1.0/a2)*
	  ( (tmpparms[vort].cos2-tmpparms[vort].sin2)*mp[i-2].re -
	    2.0*tmpparms[vort].sincos*mp[i-2].im );
	mp[i].im = -dx*mp[i-1].im - dy*mp[i-1].re +
	  2.0*s2*(i-1)*(a2-1.0/a2)*
	  ( (tmpparms[vort].cos2-tmpparms[vort].sin2)*mp[i-2].im +
	    2.0*tmpparms[vort].sincos*mp[i-2].re );
     }
}


/* MPSUM.C */
/* Copyright (c) 2000 Louis F. Rossi                                    *
 * Elliptical Corrected Core Spreading Vortex Method (ECCSVM) for the   *
 * simulation/approximation of incompressible flows.                    *

 * This program is free software; you can redistribute it and/or modify *
 * it under the terms of the GNU General Public License as published by *
 * the Free Software Foundation; either version 2 of the License, or    *
 * (at your option) any later version.					*

 * This program is distributed in the hope that it will be useful,      *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of       *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *
 * GNU General Public License for more details.                         *

 * You should have received a copy of the GNU General Public License    *
 * along with this program; if not, write to the Free Software          *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 *
 * USA                                                                  *
 *                                                                      *
 * or until 15 January 2001                                             *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Massachusetts Lowell                                   *
 * One University Ave                                                   *
 * Lowell, MA 01854                                                     *
 * 
 * or after 15 January 2001                                             *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Delaware                                               *
 * Newark, DE 19715-2553                                                */

#include "global.h"
void MP_Sum(int vort, int levels)
{
   int i,j,p,l,size,mini,maxi,minj,maxj;
   complex *Coeff_Array,z[PMax+1],tmpz;
   
   for (l=1; l<levels; ++l)
     {
	size = ldexp(1.0,l+1);
	Coeff_Array = Level_Ptr[l];
	

	maxi = 2*(gridx[l-1][vort]+2);
	maxj = 2*(gridy[l-1][vort]+2);
	mini = 2*(gridx[l-1][vort]-1);
	minj = 2*(gridy[l-1][vort]-1);

	if (maxi>size) maxi=size;
	if (maxj>size) maxj=size;
	if (mini<0) mini = 0;
	if (minj<0) minj = 0;
	     
	for (i=mini; i<maxi; ++i)
	  for (j=minj; j<maxj; ++j)
	  {
	     /* Ignore nearest neighbors. */
	     
	     if ((i < gridx[l][vort]-1) || (i > gridx[l][vort]+1) ||
		 (j < gridy[l][vort]-1) || (j > gridy[l][vort]+1) )
	       {
		  tmpz.re = (mblob[vort].blob0.x-(minX+(distX/size)*(i+0.5)));
		  tmpz.im = (mblob[vort].blob0.y-(minY+(distY/size)*(j+0.5)));
		  
		  z[0].re =  tmpz.re/(SQR(tmpz.re)+SQR(tmpz.im));
		  z[0].im = -tmpz.im/(SQR(tmpz.re)+SQR(tmpz.im));
		  
		  for (p=1; p<=PMax; ++p)
		    {
		       if (p % 2 == 1)
			 z[p] = cmult(z[p/2],z[p/2]);
		       else
			 z[p] = cmult(z[p/2],z[p/2-1]);
		    }
		  
		  for (p=0; p<PMax; ++p)
		    {
		       tmpz = cmult(z[p],*(Coeff_Array+(i+j*size)*PMax+p));
		       
		       mblob[vort].blob0.dx += tmpz.re;
		       mblob[vort].blob0.dy -= tmpz.im;
		       
		       tmpz = cmult(z[p+1],*(Coeff_Array+(i+j*size)*PMax+p));
		       
		       tmpparms[vort].du11 += -(p+1)*tmpz.re;
		       tmpparms[vort].du12 -= -(p+1)*tmpz.im;
		       tmpparms[vort].du21 -= -(p+1)*tmpz.im;
		    } /* for p */
	       } /* if not nearest neighbor */
	  } /* for i,j */
     } /* for l */
}

void MP_Direct(int vort, int levels)
{
   int i,j,size,mini,maxi,minj,maxj;
   FineGridLink *trace;
   double dx,dy,eps;
   double r[5],t[5],even[5],odd[5];
   vector v;   // an ordered pair of double= double
   tensor a;   // an ordered triple of double= double
   
   /* Now use direct summation at the finest level.  (Boo hoo) */
   
   size = (int) ldexp(1.0,levels);
   maxi = gridx[levels-1][vort]+2;
   maxj = gridy[levels-1][vort]+2;
   mini = gridx[levels-1][vort]-1;
   minj = gridy[levels-1][vort]-1;
   if (maxi>size) maxi=size;
   if (maxj>size) maxj=size;
   if (mini<0) mini = 0;
   if (minj<0) minj = 0;
  

   for (i=mini; i<maxi; ++i)
     for (j=minj; j<maxj; ++j)
     {
	trace = FineGridLinks[i+j*size];

	while (trace != NULL)
	  {
	     dx = mblob[vort].blob0.x-mblob[trace->element].blob0.x;
	     dy = mblob[vort].blob0.y-mblob[trace->element].blob0.y;

	     if ( (dx != 0.0) || (dy != 0.0) )
	       {

		   v = induced_vel(&(mblob[trace->element].blob0),
				  &(blobguts[trace->element]),
				  &(tmpparms[trace->element]),dx,dy,
				  r,t,even,odd);
		  mblob[vort].blob0.dx += v.x;
		  mblob[vort].blob0.dy += v.y;
		  
		  a = induced_veldev(&(mblob[trace->element].blob0),
				     &(blobguts[trace->element]),
				     &(tmpparms[trace->element]),dx,dy,
				     r,t,even,odd);
	     
		  tmpparms[vort].du11 += a.du11;
		  tmpparms[vort].du12 += a.du12;
		  tmpparms[vort].du21 += a.du21;
	       }
	     else
	       {
		  eps = (1.0-sqrt(blobguts[trace->element].a2))/
		    (1.0+sqrt(blobguts[trace->element].a2));
		  a.du11 = 0.0;
		  a.du12 = -(mblob[trace->element].blob0.strength/
			     (2.0*blobguts[trace->element].s2))*
		    (0.5+eps-eps*SQR(eps));
		  a.du21 = (mblob[trace->element].blob0.strength/
			    (2.0*blobguts[trace->element].s2))*
		    (0.5-eps+eps*SQR(eps));
		  
		  tmpparms[vort].du11 += (a.du11*
					  (tmpparms[trace->element].cos2-
					   tmpparms[trace->element].sin2)-
					  (a.du12+a.du21)*
					  tmpparms[trace->element].sincos);
		  
		  tmpparms[vort].du12 += (2.0*a.du11*
					  tmpparms[trace->element].sincos+
					  a.du12*
					  tmpparms[trace->element].cos2-
					  a.du21*
					  tmpparms[trace->element].sin2);
		  
		  tmpparms[vort].du21 += (2.0*a.du11*
					  tmpparms[trace->element].sincos-
					  a.du12*
					  tmpparms[trace->element].sin2+
					  a.du21*
					  tmpparms[trace->element].cos2);
		  
	       }
	     trace = trace->next;
	  }
     }
}

/* Uses a special finer grid for merging. */

void MP_Direct2(int vort, int levels)
{
   int i,j,size,mini,maxi,minj,maxj;
   FineGridLink *trace;
   double dx,dy,eps;
   double r[5],t[5],even[5],odd[5];
   vector v;
   tensor a;
   
   /* Now use direct summation at the finest level.  (Boo hoo) */
   
   size = (int) ldexp(1.0,levels);
   
   maxi = 4*(gridx[levels-1][vort]/4 + 2);
   maxj = 4*(gridy[levels-1][vort]/4 + 2);
   mini = 4*(gridx[levels-1][vort]/4 - 1);
   minj = 4*(gridy[levels-1][vort]/4 - 1);
   
   if (maxi>size) maxi=size;
   if (maxj>size) maxj=size;
   if (mini<0) mini = 0;
   if (minj<0) minj = 0;
  
   for (i=mini; i<maxi; ++i)
     for (j=minj; j<maxj; ++j)
       {
	  trace = FineGridLinks[i+j*size];

	  while (trace != NULL)
	    {	    	    
	       dx = mblob[vort].blob0.x-mblob[trace->element].blob0.x;
	       dy = mblob[vort].blob0.y-mblob[trace->element].blob0.y;

	       if ( (dx != 0.0) || (dy != 0.0) )
		 {
		    v = induced_vel(&(mblob[trace->element].blob0),
				    &(blobguts[trace->element]),
				    &(tmpparms[trace->element]),dx,dy,
				    r,t,even,odd);
		    mblob[vort].blob0.dx += v.x;
		    mblob[vort].blob0.dy += v.y;
		    
		    a = induced_veldev(&(mblob[trace->element].blob0),
				       &(blobguts[trace->element]),
				       &(tmpparms[trace->element]),dx,dy,
				       r,t,even,odd);
		    
		    tmpparms[vort].du11 += a.du11;
		    tmpparms[vort].du12 += a.du12;
		    tmpparms[vort].du21 += a.du21;
		 }
	       else
		 {
		    eps = (1.0-sqrt(blobguts[trace->element].a2))/
		      (1.0+sqrt(blobguts[trace->element].a2));
		    a.du11 = 0.0;
		    a.du12 = -(mblob[trace->element].blob0.strength/
			       (2.0*blobguts[trace->element].s2))*
		      (0.5+eps-eps*SQR(eps));
		    a.du21 = (mblob[trace->element].blob0.strength/
			      (2.0*blobguts[trace->element].s2))*
		      (0.5-eps+eps*SQR(eps));
		    
		    tmpparms[vort].du11 += (a.du11*
					    (tmpparms[trace->element].cos2-
					     tmpparms[trace->element].sin2)-
					    (a.du12+a.du21)*
					    tmpparms[trace->element].sincos);
		    
		    tmpparms[vort].du12 += (2.0*a.du11*
					    tmpparms[trace->element].sincos+
					    a.du12*
					    tmpparms[trace->element].cos2-
					    a.du21*
					    tmpparms[trace->element].sin2);
		    
		    tmpparms[vort].du21 += (2.0*a.du11*
					    tmpparms[trace->element].sincos-
					    a.du12*
					    tmpparms[trace->element].sin2+
					    a.du21*
					    tmpparms[trace->element].cos2);
		 }
	       trace = trace->next;
	    }
       }
}

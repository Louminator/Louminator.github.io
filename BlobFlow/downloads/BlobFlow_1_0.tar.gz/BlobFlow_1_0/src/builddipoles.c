#include <stdio.h>
#include <math.h>

#define SQR(X) ((X)*(X))

void main()
{
   int  i,j,k,N;
   double dx,dy,s2,blobs2,gamma,str,pi,x,y;
   
   x = 1.0;
   y = 1.0;
   N = 20;
   dx = x/(N/2.0);
   dy = y/(N/2.0);
   s2 = 0.09;
   blobs2 = 2.0647e-2;
   pi = 4.0*atan(1.0);
   gamma = 4.0*pi;
   
   for (i=-N/2; i<(N/2)+1; ++i)
     for (j=-N/2; j<(N/2)+1; ++j)
       if (SQR(i*dx)+SQR(j*dy) < SQR(x))
     {
	str = (gamma/(4.0*pi*(s2-blobs2)))*
	  (exp(-(SQR(i*dx)+SQR(j*dy-0.25))/(4.0*(s2-blobs2)))-
	   exp(-(SQR(i*dx)+SQR(j*dy+0.25))/(4.0*(s2-blobs2))));
	
	printf("%10.6e %10.6e %10.6e %10.6e 1.0 0.0\n",
	       i*dx-2.0,j*dy,str*dx*dy/(2.0*pi),blobs2);
     }

   gamma = 3.0*pi;
   for (i=-N/2; i<(N/2)+1; ++i)
     for (j=-N/2; j<(N/2)+1; ++j)
       if (SQR(i*dx)+SQR(j*dy) < SQR(x))
     {
	str = (gamma/(4.0*pi*(s2-blobs2)))*
	  (exp(-(SQR(i*dx)+SQR(j*dy+0.25))/(4.0*(s2-blobs2)))-
	   exp(-(SQR(i*dx)+SQR(j*dy-0.25))/(4.0*(s2-blobs2))));
	
	printf("%10.6e %10.6e %10.6e %10.6e 1.0 0.0\n",
	       i*dx+2.0,j*dy,str*dx*dy/(2.0*pi),blobs2);
     }
}

/* PARTITION.C */
/* Copyright (c) 2000 Louis F. Rossi                                    *
 * Elliptical Corrected Core Spreading Vortex Method (ECCSVM) for the   *
 * simulation/approximation of incompressible flows.                    *

 * This program is free software; you can redistribute it and/or modify *
 * it under the terms of the GNU General Public License as published by *
 * the Free Software Foundation; either version 2 of the License, or    *
 * (at your option) any later version.					*

 * This program is distributed in the hope that it will be useful,      *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of       *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *
 * GNU General Public License for more details.                         *

 * You should have received a copy of the GNU General Public License    *
 * along with this program; if not, write to the Free Software          *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 *
 * USA                                                                  *
 *                                                                      *
 * or until 15 January 2001                                             *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Massachusetts Lowell                                   *
 * One University Ave                                                   *
 * Lowell, MA 01854                                                     *
 * 
 * or after 15 January 2001                                             *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Delaware                                               *
 * Newark, DE 19715-2553                                                */

#include "global.h"

int C(int n, int k)
{
   int i,sum;
   
   sum = 1;
   if (n != 0)
     {
	for (i=1; i<=n; ++i)
	  sum *= i;
	for (i=1; i<=k; ++i)
	  sum /= i;
	for (i=1; i<=n-k; ++i)
	  sum /= i;
     }
   return(sum);
}

complex cpowi(c,n)
complex c;
int     n;
{
   int     i;
   complex result;
   
   result = c;
   
   for (i=1; i<n; ++i)
     result = cmult(result,c);
 
   return(result);
}

complex cmult(c1,c2)
complex c1,c2;
{
   complex result;
   
   result.re = c1.re*c2.re-c1.im*c2.im;
   result.im = c1.re*c2.im+c1.im*c2.re;
   
   return(result);
}

int Set_Level()
{
   int i;
   int level1,level2,level;
   double maxa2,mingrid;
   
   minX = mblob[0].blob0.x;
   maxX = mblob[0].blob0.x;
   minY = mblob[0].blob0.y;
   maxY = mblob[0].blob0.y;
   for (i=1; i<N; ++i)
     {
	if (mblob[i].blob0.x<minX) minX = mblob[i].blob0.x; 
	if (mblob[i].blob0.x>maxX) maxX = mblob[i].blob0.x; 
	if (mblob[i].blob0.y<minY) minY = mblob[i].blob0.y; 
	if (mblob[i].blob0.y>maxY) maxY = mblob[i].blob0.y; 
     }
   
   distX = maxX-minX;
   distY = maxY-minY;
   
   /* Make the grid a square and center it. */
   
   if (distY > distX)
     {
	minX -= (distY-distX)/2.0;
	maxX += (distY-distX)/2.0;
	distX = distY;
     }
   else
     {
	minY -= (distX-distY)/2.0;
	maxY += (distX-distY)/2.0;
	distY = distX;
     }
   
   maxa2 = 1.0;
   
   for (i=1; i<N; ++i)
     {
	if (1.0/blobguts[i].a2 > maxa2)
	  maxa2 = 1.0/blobguts[i].a2;
	else
	  if (blobguts[i].a2 > maxa2)
	    maxa2 = blobguts[i].a2;
     }
   
   /* 10 elements per cell. */
   level1 = (int) (log(N/10.0)/log(4.0)+0.5);
   
   /* Adequate overlap. */
/*   level2 = (int) (log(distX/4.0/sqrt(l2tol*maxa2)+1.0)/log(2.0) + 0.5); */
/*   level2 = (int) (log(distX/8.0/sqrt(l2tol*maxa2)+1.0)/log(2.0) + 0.5); */
   
   /* Using a finer mesh for merging */
   level2 = (int) (log(distX/2.0/sqrt(l2tol*maxa2)+1.0)/log(2.0) + 0.5);
   
   if (level1>level2)
     level = level2;
   else
     level = level1;
   
   if (level > LMax) level = LMax;
   if (level < 1) level = 1;
   
   mingrid = distX/(ldexp(1.0,level)+1);
   distX += mingrid;
   distY += mingrid;
   minX -= mingrid/2.0;
   maxX += mingrid/2.0;
   minY -= mingrid/2.0;
   maxY += mingrid/2.0;
   
   return(level);
}

void partition(int levels)
{
   int i,l,size;
   FineGridLink *addone;
   
   /* Create a membership list for each vortex. */
   for (l=0; l<levels; ++l)
     {
	for (i=0; i<N; ++i)
	  {
	     gridx[l][i] = (int) 
	       ( (mblob[i].blob0.x-minX)*ldexp(1.0,l+1)/distX );
	     
	     gridy[l][i] = (int) 
	       ( (mblob[i].blob0.y-minY)*ldexp(1.0,l+1)/distY );
	     
	     /* Just in case the position is at the extreme. */
	     if (gridx[l][i] == (int) ldexp(1.0,l+1)) --gridx[l][i];
	     if (gridy[l][i] == (int) ldexp(1.0,l+1)) --gridy[l][i];
	  }
     }
   
   size = (int) ldexp(1.0,levels);
   
   FineGridLinks = malloc(sizeof(*addone)*SQR(size));
   
   for (i=0; i<SQR(size); ++i)
     FineGridLinks[i] = NULL;

   for (i=0; i<N; ++i)
     {
	addone = malloc(sizeof(*addone));
	addone->element = i;
	if ((FineGridLinks[gridx[levels-1][i]+size*gridy[levels-1][i]]) 
	    == NULL)
	  {
	    FineGridLinks[gridx[levels-1][i]+size*gridy[levels-1][i]] = 
	      addone;
	    addone->next = NULL;
	  }
	else
	  {   /* insert */
	    addone->next = 
	      FineGridLinks[gridx[levels-1][i]+size*gridy[levels-1][i]];
	    FineGridLinks[gridx[levels-1][i]+size*gridy[levels-1][i]]  = 
	      addone;
	  }
     }
}

void Init_Fine_Grid(int levels)
{
   int i,j,p,size;
   complex *Coeff_Array,tmpz,dz,mp[PMax];
   
   Coeff_Array = Level_Ptr[levels-1];
   
   /* Wipe the finest level mesh */
   tmpz.re = 0.0; tmpz.im = 0.0;
   size = (int) ldexp(1.0,levels);
   
   for (i=0; i < size; ++i)
     for (j=0; j < size; ++j)
       for (p=0; p<PMax; ++p)
	 *(Coeff_Array+(i+j*size)*PMax+p) = tmpz;
   
   for (i=0; i<N; ++i)
     {
	dz.re=(minX+(gridx[levels-1][i]+0.5)*(distX/size))-mblob[i].blob0.x;
	dz.im=(minY+(gridy[levels-1][i]+0.5)*(distY/size))-mblob[i].blob0.y;

	Calc_Coeffs(i,dz,mp);
	
	for (p=0; p<PMax; ++p)
	  {
	     (*(Coeff_Array+
	       (gridx[levels-1][i]+gridy[levels-1][i]*size)*PMax+p)).re +=
	       mp[p].re;
	     (*(Coeff_Array+
	       (gridx[levels-1][i]+gridy[levels-1][i]*size)*PMax+p)).im +=
	       mp[p].im;
	  }
     }
}

/* Use coefficients at the finest level and pass them up to the coarsest 
 level */

void Advance_Coeffs(int levels)
{
   int i,j,p,p1,l,size;
   complex *Coeff_Array,*Coeff_Array_Finer,tmpz,dz[PMax+1];
   
   for (l=levels-2; l>=0; --l)
     {
	Coeff_Array = Level_Ptr[l];
	Coeff_Array_Finer = Level_Ptr[l+1];
	size = ldexp(1.0,l+1);
	
	/* Wipe the current layer */
	tmpz.re = 0.0; tmpz.im = 0.0;
	for (i=0; i<size; ++i)
	  for (j=0; j<size; ++j)
	    for (p=0; p<PMax; ++p)
	      *(Coeff_Array+(i+j*size)*PMax+p) = tmpz;

	dz[0].re = 1.0;
	dz[0].im = 0.0;
	
	
	/* Lower left children */
	
	dz[1].re = -distX/size/4.0;
	dz[1].im = -distY/size/4.0;
	
	for (p=2; p<=PMax; ++p)
	  {
	     if (p % 2 == 0)
	       dz[p] = cmult(dz[p/2],dz[p/2]);
	     else
	       dz[p] = cmult(dz[p/2],dz[(p/2)+1]);
	  }

	for (i=0; i<size; ++i)
	  for (j=0; j<size; ++j)
	    for (p=0; p<PMax; ++p)
	      for (p1=0; p1<=p; ++p1)
	  {
	     tmpz = cmult(dz[p-p1],
			  *(Coeff_Array_Finer+(2*i+2*j*2*size)*PMax+p1));
	     (*(Coeff_Array+(i+j*size)*PMax+p)).re +=
	       tmpz.re*C(p,p1);
	     (*(Coeff_Array+(i+j*size)*PMax+p)).im +=
	       tmpz.im*C(p,p1);
	  }

     	/* Lower right children */
	
	dz[1].re =  distX/size/4.0;
	dz[1].im = -distY/size/4.0;
	
	for (p=2; p<=PMax; ++p)
	  {
	     if (p % 2 == 0)
	       dz[p] = cmult(dz[p/2],dz[p/2]);
	     else
	       dz[p] = cmult(dz[p/2],dz[(p/2)+1]);
	  }

	for (i=0; i<size; ++i)
	  for (j=0; j<size; ++j)
	    for (p=0; p<PMax; ++p)
	      for (p1=0; p1<=p; ++p1)
	  {
	     tmpz = cmult(dz[p-p1],
			  *(Coeff_Array_Finer+(2*i+1+2*j*2*size)*PMax+p1));
	     (*(Coeff_Array+(i+j*size)*PMax+p)).re +=
	       tmpz.re*C(p,p1);
	     (*(Coeff_Array+(i+j*size)*PMax+p)).im +=
	       tmpz.im*C(p,p1);
	  }

     	/* Upper left children */
	
	dz[1].re = -distX/size/4.0;
	dz[1].im =  distY/size/4.0;
	
	for (p=2; p<=PMax; ++p)
	  {
	     if (p % 2 == 0)
	       dz[p] = cmult(dz[p/2],dz[p/2]);
	     else
	       dz[p] = cmult(dz[p/2],dz[(p/2)+1]);
	  }

	for (i=0; i<size; ++i)
	  for (j=0; j<size; ++j)
	    for (p=0; p<PMax; ++p)
	      for (p1=0; p1<=p; ++p1)
	  {
	     tmpz = cmult(dz[p-p1],
			  *(Coeff_Array_Finer+(2*i+(2*j+1)*2*size)*PMax+p1));
	     (*(Coeff_Array+(i+j*size)*PMax+p)).re +=
	       tmpz.re*C(p,p1);
	     (*(Coeff_Array+(i+j*size)*PMax+p)).im +=
	       tmpz.im*C(p,p1);
	  }

     	/* Upper right children */
	
	dz[1].re =  distX/size/4.0;
	dz[1].im =  distY/size/4.0;
	
	for (p=2; p<=PMax; ++p)
	  {
	     if (p % 2 == 0)
	       dz[p] = cmult(dz[p/2],dz[p/2]);
	     else
	       dz[p] = cmult(dz[p/2],dz[(p/2)+1]);
	  }

	for (i=0; i<size; ++i)
	  for (j=0; j<size; ++j)
	    for (p=0; p<PMax; ++p)
	      for (p1=0; p1<=p; ++p1)
	  {
	     tmpz = cmult(dz[p-p1],
			  *(Coeff_Array_Finer+(2*i+1+(2*j+1)*2*size)*PMax+p1));
	     (*(Coeff_Array+(i+j*size)*PMax+p)).re +=
	       tmpz.re*C(p,p1);
	     (*(Coeff_Array+(i+j*size)*PMax+p)).im +=
	       tmpz.im*C(p,p1);
	  }
     }
}

void Release_Links(int levels)
{
   int i,size;
   FineGridLink *takeone,*taketwo;
   
   size = ldexp(1.0,levels);
   
   for (i=0; i<SQR(size); ++i)
     {
	takeone = *(FineGridLinks+i);
	
	while (takeone != NULL)
	  {
	     taketwo = takeone;
	     takeone = takeone->next;
	     free(taketwo);
	  }
     }
   free(FineGridLinks);
}

void Create_Hierarchy()
{
   mplevels = Set_Level();
   partition(mplevels);
   Init_Fine_Grid(mplevels);
   Advance_Coeffs(mplevels);
}

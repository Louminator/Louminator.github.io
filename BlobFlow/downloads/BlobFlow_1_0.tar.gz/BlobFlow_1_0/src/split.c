/* SPLIT.C */
/* Copyright (c) 2000 Louis F. Rossi                                    *
 * Elliptical Corrected Core Spreading Vortex Method (ECCSVM) for the   *
 * simulation/approximation of incompressible flows.                    *

 * This program is free software; you can redistribute it and/or modify *
 * it under the terms of the GNU General Public License as published by *
 * the Free Software Foundation; either version 2 of the License, or    *
 * (at your option) any later version.					*

 * This program is distributed in the hope that it will be useful,      *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of       *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *
 * GNU General Public License for more details.                         *

 * You should have received a copy of the GNU General Public License    *
 * along with this program; if not, write to the Free Software          *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 *
 * USA                                                                  *
 *                                                                      *
 * or until 15 January 2001                                             *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Massachusetts Lowell                                   *
 * One University Ave                                                   *
 * Lowell, MA 01854                                                     *
 * 
 * or after 15 January 2001                                             *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Delaware                                               *
 * Newark, DE 19715-2553                                                */

#include "global.h"

void split12(the_blob,the_blobguts,parms,new_blob,new_blobguts,new_parms)
blob_external *the_blob,*new_blob;
blob_internal *the_blobguts,*new_blobguts;
blobparms *parms,*new_parms;
{
   blob_external old_blob;
   blob_internal old_blobguts;
   double     r,r2;
   double     thisalpha;
   
   if (N >= NMax)
     {
	fprintf(comp_log,
		"Overload!  The problem size has grown beyond NMax.\n");
	stop(-1);
     }
   
   old_blob = *the_blob;
   *new_blob = *the_blob;
   old_blobguts = *the_blobguts;
   *new_blobguts = *the_blobguts;
   
   thisalpha = alpha;

   (*the_blobguts).s2 = old_blobguts.s2*thisalpha*thisalpha;
   (*new_blobguts).s2 = (*the_blobguts).s2;
   
   (*the_blob).strength = old_blob.strength/2.0;
   (*new_blob).strength = old_blob.strength/2.0;
   
   if (old_blobguts.a2 > 1.0)
     {
	r2 = old_blobguts.s2*old_blobguts.a2*2.0*(1.0-SQR(SQR(thisalpha)));
	r = sqrt(r2);
	(*the_blobguts).a2 = thisalpha*thisalpha*old_blobguts.a2;
	(*new_blobguts).a2 = (*the_blobguts).a2;
	
	(*the_blob).x = old_blob.x + r*(*parms).costh;
	(*the_blob).y = old_blob.y + r*(*parms).sinth;
	
	(*new_blob).x = old_blob.x - r*(*parms).costh;
	(*new_blob).y = old_blob.y - r*(*parms).sinth;
	
     }
   else
     {
	r2 = 2.0*(1.0-SQR(SQR(thisalpha)))*old_blobguts.s2/old_blobguts.a2;
	r = sqrt(r2);
	(*the_blobguts).a2 = old_blobguts.a2/SQR(thisalpha);
	(*new_blobguts).a2 = (*the_blobguts).a2;
	
	(*the_blob).x = old_blob.x + r*(*parms).sinth;
	(*the_blob).y = old_blob.y - r*(*parms).costh;
	
	(*new_blob).x = old_blob.x - r*(*parms).sinth;
	(*new_blob).y = old_blob.y + r*(*parms).costh;
     }
   
   (*the_blob).order = 1;
   (*new_blob).order = 1;
   set_blob(the_blobguts,parms);
   set_blob(new_blobguts,new_parms);
}

/* Same as buildmonopole except uses a circular configuration. */

#include <stdio.h>
#include <math.h>

#define SQR(X) ((X)*(X))

void main()
{
   int  i,j,N,ntheta;
   double r,dr,s2,blobs2,gamma,str,pi,dtheta,cenr;
   FILE *fopen(),*paramfile;
   
   paramfile = fopen("monopole.dat","r");
   fscanf(paramfile,"%d",&N);
   fscanf(paramfile,"%lf",&r);
   fscanf(paramfile,"%lf",&s2);
   fscanf(paramfile,"%lf",&blobs2);
   fclose(paramfile);
   
   dr = r/N;
   pi = 4.0*atan(1.0);
   gamma = pi;
   
   for (i=0; i<N; ++i)
     {
	ntheta = (int) ((2.0*i+1.0)*pi);
	dtheta = 2.0*pi/ntheta;
	
	cenr = (4.0/3.0)*sin(dtheta/2.0)*dr*((i+1.0)*SQR(i+1.0)-i*SQR(i))/
	  (SQR(i+1.0)-SQR(i))/dtheta;
	
	for (j=0; j<ntheta; ++j)
	  {
	     str = (gamma/ntheta)*
	       (exp(-(SQR(dr*i))/(4.0*(s2-blobs2)))-
		exp(-(SQR(dr*(i+1.0)))/(4.0*(s2-blobs2))));
	     
	     printf("%10.6e %10.6e %10.6e %10.6e 1.0 0.0\n",
/*		    dr*(i+0.5)*cos(j*dtheta),
		    dr*(i+0.5)*sin(j*dtheta), */
		    cenr*cos(j*dtheta),cenr*sin(j*dtheta),
		    str/(2.0*pi),
		    blobs2);
	  }
     }
}

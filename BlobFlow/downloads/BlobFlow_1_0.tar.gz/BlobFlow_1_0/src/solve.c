/* SOLVE.C */
/* Copyright (c) 2000 Louis F. Rossi                                    *
 * Elliptical Corrected Core Spreading Vortex Method (ECCSVM) for the   *
 * simulation/approximation of incompressible flows.                    *

 * This program is free software; you can redistribute it and/or modify *
 * it under the terms of the GNU General Public License as published by *
 * the Free Software Foundation; either version 2 of the License, or    *
 * (at your option) any later version.					*

 * This program is distributed in the hope that it will be useful,      *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of       *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *
 * GNU General Public License for more details.                         *

 * You should have received a copy of the GNU General Public License    *
 * along with this program; if not, write to the Free Software          *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 *
 * USA                                                                  *
 *                                                                      *
 * or until 15 January 2001                                             *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Massachusetts Lowell                                   *
 * One University Ave                                                   *
 * Lowell, MA 01854                                                     *
 * 
 * or after 15 January 2001                                             *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Delaware                                               *
 * Newark, DE 19715-2553                                                */

#include "global.h"

void push(mblob)
    metablob *mblob;
{
    (*mblob).blob4 = (*mblob).blob3;
    (*mblob).blob3 = (*mblob).blob2;
    (*mblob).blob2 = (*mblob).blob1;
    (*mblob).blob1 = (*mblob).blob0;
}

void set_blob(the_blobguts,parms)
blob_internal *the_blobguts;
blobparms *parms;
{
    (*parms).costh = cos((*the_blobguts).th);
    (*parms).sinth = sin((*the_blobguts).th);
    (*parms).cos2 = SQR((*parms).costh);
    (*parms).sin2 = SQR((*parms).sinth);
    (*parms).sincos = (*parms).sinth*(*parms).costh;
}

void chksplit()
{
   int i;
 
   for (i=0; i<oldN; ++i)
     if ( blobguts[i].s2 > l2tol )
     {
	split12(&(mblob[i].blob0),&(blobguts[i]),&(tmpparms[i]),
		&(mblob[N].blob0),&(blobguts[N]),&(tmpparms[N]));
	++nsplit;
	++N;
     }
}

void deriv_ext(the_blob,parms)
blob_external *the_blob;
blobparms *parms;
{

   dpos_vel(the_blob,parms);

}
/* called from run() in evolve.c  */
/*  jump to file:  deriv.c  */
void deriv_ext_fast(int vort)
{
   dpos_vel_fast(vort);
}


void ab2(mblob,parms,timestep)
metablob *mblob;
blobparms *parms;
double timestep;
{
   (*mblob).blob0.x  += 
     timestep*(1.5*(*mblob).blob1.dx  - 0.5*(*mblob).blob2.dx);
   (*mblob).blob0.y  += 
     timestep*(1.5*(*mblob).blob1.dy  - 0.5*(*mblob).blob2.dy);
}

void ab3(mblob,parms,timestep)
metablob *mblob;
blobparms *parms;
double timestep;
{
   (*mblob).blob0.x  = (*mblob).blob1.x + 
	timestep*((23.0/12.0)*(*mblob).blob1.dx - 
		  (4.0/3.0)*(*mblob).blob2.dx + 
		  (5.0/12.0)*(*mblob).blob3.dx);
   (*mblob).blob0.y  = (*mblob).blob1.y + 
     timestep*((23.0/12.0)*(*mblob).blob1.dy - 
	       (4.0/3.0)*(*mblob).blob2.dy + 
	       (5.0/12.0)*(*mblob).blob3.dy);
}

void ab4(mblob,timestep)
metablob *mblob;
double timestep;
{
    (*mblob).blob0.x  += (timestep/24.0)*(55.0*(*mblob).blob1.dx - 
					59.0*(*mblob).blob2.dx + 
					37.0*(*mblob).blob3.dx - 
					9.0*(*mblob).blob4.dx);
    (*mblob).blob0.y  += (timestep/24.0)*(55.0*(*mblob).blob1.dy - 
					59.0*(*mblob).blob2.dy + 
					37.0*(*mblob).blob3.dy - 
					9.0*(*mblob).blob4.dy);
}

void am4(mblob,timestep)
metablob *mblob;
double timestep;
{
    (*mblob).blob0.x  = (*mblob).blob1.x + 
	(timestep/24.0)*(9.0*(*mblob).blob0.dx + 
			 19.0*(*mblob).blob1.dx - 
			 5.0*(*mblob).blob2.dx + 
			 (*mblob).blob3.dx);
    (*mblob).blob0.y  = (*mblob).blob1.y + 
	(timestep/24.0)*(9.0*(*mblob).blob0.dy + 
			 19.0*(*mblob).blob1.dy - 
			 5.0*(*mblob).blob2.dy + 
			 (*mblob).blob3.dy);
}

void rk4march(blobguts,parms,prefstep,steps)
blob_internal *blobguts;
blobparms *parms;
double prefstep;
int       steps;
{
   blob_internal tempguts[5];
   blobparms     tempparms[5];
   double     ds2[4],da2[4],dth[4],dumb;
   int           i;
   
   tempguts[0] = *blobguts;
   tempparms[0] = *parms;

   for (i=0; i<steps; ++i)
     {
	set_blob(&(tempguts[0]),&(tempparms[0]));
	
	/* Check for rapid reorientation. */
	if (fabs(tempguts[0].a2 - 1.0) < 1.0e-8)
	  {
	     if (tempparms[0].du12+tempparms[0].du21 == 0.0)
	       tempguts[0].th = 0.0;
	     else
	       {
		  dumb = (4.0*tempparms[0].du11)/
		    (tempparms[0].du21+tempparms[0].du12);
		  
		  tempguts[0].th = 
		    atan((-dumb-sqrt(SQR(dumb)+4.0))/2.0);
	       }
	     set_blob(&(tempguts[0]),&(tempparms[0]));
	     dth[0] = (tempparms[0].du21-tempparms[0].du12)/2.0;
	  }
	else
	  dth[0] = dtth(&(tempguts[0]),&(tempparms[0]));
	
	ds2[0] = dts2(&(tempguts[0]));
	da2[0] = dta2(&(tempguts[0]),&(tempparms[0]));
	
	/* Forward Euler */
	
	tempguts[1].th = tempguts[0].th+0.5*prefstep*dth[0];
	tempguts[1].s2 = tempguts[0].s2+0.5*prefstep*ds2[0];
	tempguts[1].a2 = tempguts[0].a2+0.5*prefstep*da2[0];
	tempparms[1] = tempparms[0];
	set_blob(&(tempguts[1]),&(tempparms[1]));
	
	/* Check for rapid reorientation. */
	if (fabs(tempguts[1].a2 - 1.0) < 1.0e-8)
	  {
	     if (tempparms[1].du12+tempparms[1].du21 == 0.0)
	       tempguts[1].th = 0.0;
	     else
	       {
		  dumb = (4.0*tempparms[1].du11)/
		    (tempparms[1].du21+tempparms[1].du12);
		  
		  tempguts[1].th = 
		    atan((-dumb-sqrt(SQR(dumb)+4.0))/2.0);
	       }
	     set_blob(&(tempguts[1]),&(tempparms[1]));
	     dth[1] = (tempparms[1].du21-tempparms[1].du12)/2.0;
	  }
	else
	  dth[1] = dtth(&(tempguts[1]),&(tempparms[1]));
	
	ds2[1] = dts2(&(tempguts[1]));
	da2[1] = dta2(&(tempguts[1]),&(tempparms[1]));
	
	/* Backward Euler */
	
	tempguts[2].th = tempguts[0].th+0.5*prefstep*dth[1];
	tempguts[2].s2 = tempguts[0].s2+0.5*prefstep*ds2[1];
	tempguts[2].a2 = tempguts[0].a2+0.5*prefstep*da2[1];
	tempparms[2] = tempparms[1];
	set_blob(&(tempguts[2]),&(tempparms[2]));
	
	/* Check for rapid reorientation. */
	if (fabs(tempguts[2].a2 - 1.0) < 1.0e-8)
	  {
	     if (tempparms[2].du12+tempparms[2].du21 == 0.0)
	       tempguts[2].th = 0.0;
	     else
	       {
		  dumb = (4.0*tempparms[2].du11)/
		    (tempparms[2].du21+tempparms[2].du12);
		  
		  tempguts[2].th = 
		    atan((-dumb-sqrt(SQR(dumb)+4.0))/2.0);
	       }
	     set_blob(&(tempguts[2]),&(tempparms[2]));
	     dth[2] = (tempparms[2].du21-tempparms[2].du12)/2.0;
	  }
	else
	  dth[2] = dtth(&(tempguts[2]),&(tempparms[2]));
	
	ds2[2] = dts2(&(tempguts[2]));
	da2[2] = dta2(&(tempguts[2]),&(tempparms[2]));
	
	/* Midpoint rule. */
	tempguts[3].th = tempguts[0].th+prefstep*dth[2];
	tempguts[3].s2 = tempguts[0].s2+prefstep*ds2[2];
	tempguts[3].a2 = tempguts[0].a2+prefstep*da2[2];
	tempparms[3] = tempparms[2];
	set_blob(&(tempguts[3]),&(tempparms[3]));
	
	/* Check for rapid reorientation. */
	if (fabs(tempguts[3].a2 - 1.0) < 1.0e-8)
	  {
	     if (tempparms[3].du12+tempparms[3].du21 == 0.0)
	       tempguts[3].th = 0.0;
	     else
	       {
		  dumb = (4.0*tempparms[3].du11)/
		    (tempparms[3].du21+tempparms[3].du12);
		  
		  tempguts[3].th = 
		    atan((-dumb-sqrt(SQR(dumb)+4.0))/2.0);
	       }
	     set_blob(&(tempguts[3]),&(tempparms[3]));
	     dth[3] = (tempparms[3].du21-tempparms[3].du12)/2.0;
	  }
	else
	  dth[3] = dtth(&(tempguts[3]),&(tempparms[3]));
	
	ds2[3] = dts2(&(tempguts[3]));
	da2[3] = dta2(&(tempguts[3]),&(tempparms[3]));
	
	/* Simpson's rule corrector. */
	tempguts[4].th = tempguts[0].th+
	  prefstep*(dth[0] + 2.0*dth[1] + 2.0*dth[2] + dth[3])/6.0;
	tempguts[4].s2 = tempguts[0].s2+
	  prefstep*(ds2[0] + 2.0*ds2[1] + 2.0*ds2[2] + ds2[3])/6.0;
	tempguts[4].a2 = tempguts[0].a2+
	  prefstep*(da2[0] + 2.0*da2[1] + 2.0*da2[2] + da2[3])/6.0;
	tempparms[4] = tempparms[3];
	set_blob(&(tempguts[4]),&(tempparms[4]));
	
	tempguts[0] = tempguts[4];
	tempparms[0] = tempparms[4];
     }
   
   *blobguts = tempguts[4];
   *parms    = tempparms[4];
}
   
void rk4internal(blobguts,parms,timestep)
blob_internal *blobguts;
blobparms *parms;
double timestep;
{
   int           steps,crashtest;
   double     prefstep,err;
   blob_internal testblob1,testblob2;
   blobparms     testparm1,testparm2;
   
   
   testblob1 = *blobguts;
   testblob2 = *blobguts;
   testparm1 = *parms;
   testparm2 = *parms;
   
   crashtest = 0;
   steps = 4;
   prefstep = timestep/4.0;
   
   rk4march(&testblob1,&testparm1,prefstep,steps);
   
   steps *= 2;
   prefstep /= 2.0;
   rk4march(&testblob2,&testparm2,prefstep,steps);
   
   err =
     SQR(testblob1.a2 - testblob2.a2) +
     SQR(testblob1.s2 - testblob2.s2) +
     SQR(testblob1.th - testblob2.th);
   
   while ( (err > 1.0e-10) &&  (crashtest < 20) )
     {
	++crashtest;
	
	testblob1 = testblob2;
	testparm1 = testparm2;
	testblob2 = *blobguts;
	testparm2 = *parms;
	
	steps *= 2;
	prefstep /= 2.0;
	rk4march(&testblob2,&testparm2,prefstep,steps);
	
   
	err =
	  SQR(testblob1.a2 - testblob2.a2) +
	  SQR(testblob1.s2 - testblob2.s2) +
	  SQR(testblob1.th - testblob2.th);

     }
   
   if ( (crashtest == 20) && 
       (SQR(testblob1.a2 - testblob2.a2) +
	    SQR(testblob1.s2 - testblob2.s2) +
	    SQR(testblob1.th - testblob2.th) > 1.0e-10) )
	printf("RK4 failed to converge.  Error: %10.4e\n",
	       SQR(testblob1.a2 - testblob2.a2) +
	       SQR(testblob1.s2 - testblob2.s2) +
	       SQR(testblob1.th - testblob2.th));
   
   *blobguts = testblob2;
   *parms    = testparm2;
}

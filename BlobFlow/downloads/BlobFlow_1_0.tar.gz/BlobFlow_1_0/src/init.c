/* INIT-MS.C */
/* Copyright (c) 2000 Louis F. Rossi                                    *
 * Elliptical Corrected Core Spreading Vortex Method (ECCSVM) for the   *
 * simulation/approximation of incompressible flows.                    *

 * This program is free software; you can redistribute it and/or modify *
 * it under the terms of the GNU General Public License as published by *
 * the Free Software Foundation; either version 2 of the License, or    *
 * (at your option) any later version.					*

 * This program is distributed in the hope that it will be useful,      *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of       *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *
 * GNU General Public License for more details.                         *

 * You should have received a copy of the GNU General Public License    *
 * along with this program; if not, write to the Free Software          *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 *
 * USA                                                                  *
 *                                                                      *
 * or until 15 January 2001                                             *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Massachusetts Lowell                                   *
 * One University Ave                                                   *
 * Lowell, MA 01854                                                     *
 * 
 * or after 15 January 2001                                             *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Delaware                                               *
 * Newark, DE 19715-2553                                                */

/* Initialization subroutines for eflow. */

#include "global.h"

#ifdef MULTIPROC
#include "multiproc.h"
#endif

#ifdef XANTISYMM
#define CARDINALITY  N/2
#else
#define CARDINALITY  N
#endif

/* Script constants. */
static char *inputs[] =
{
   "FrameStep:",
   "EndTime:",
   "Viscosity:",
   "VtxInit:",
   "TimeStep:",
   "l2Tol:",
   "alpha:",
   "MergeBudget:",
   "MergeStep:",
   "ClusterRadius:",
   "Mergea2Tol:",
   "MergeThTol:"
};

enum ScriptItems 
{FRAME_STEP,END_TIME,VISCOSITY,VTX_INIT,
   TIME_STEP,L2_TOL,ALPHA,MERGE_BUDGET,MERGE_STEP,CLUSTER_RADIUS,
   MERGE_A2_TOL,MERGE_TH_TOL
};

void chkvel()
{
   int vort;
   double tmpr2,tmpvx,tmpvy,avgrel,avgabs;
   
   avgabs = 0.0;
   avgrel = 0.0;
	
   for (vort=0; vort<N; ++vort)
     {
	tmpr2 = SQR(mblob[vort].blob0.x)+SQR(mblob[vort].blob0.y);
	tmpvx = -0.5*(mblob[vort].blob0.y/tmpr2)*(1.0-exp(-tmpr2/4.0/0.025));
	tmpvy =  0.5*(mblob[vort].blob0.x/tmpr2)*(1.0-exp(-tmpr2/4.0/0.025));
	
	if (isnan(tmpvx)) tmpvx = 0.0;
	if (isnan(tmpvy)) tmpvy = 0.0;
	
	if (SQR(mblob[vort].blob0.x)+SQR(mblob[vort].blob0.y)<SQR(0.25))
	  {
	     printf("%d %12.4e %12.4e\n",
		    vort,
		    sqrt(SQR(tmpvx-mblob[vort].blob0.dx)+
			 SQR(tmpvy-mblob[vort].blob0.dy)),
		    sqrt(SQR(tmpvx-mblob[vort].blob0.dx)+
			 SQR(tmpvy-mblob[vort].blob0.dy))/
		    sqrt(SQR(mblob[vort].blob0.dx)+
			 SQR(mblob[vort].blob0.dy)));
	     avgabs += sqrt(SQR(tmpvx-mblob[vort].blob0.dx)+
			 SQR(tmpvy-mblob[vort].blob0.dy));
	     avgrel += sqrt(SQR(tmpvx-mblob[vort].blob0.dx)+
			    SQR(tmpvy-mblob[vort].blob0.dy))/
	       sqrt(SQR(mblob[vort].blob0.dx)+
		    SQR(mblob[vort].blob0.dy));
	  }
     }
   printf("%12.4e %12.4e\n",avgabs/N,avgrel/N);
   exit(1);
}
   
void chkvel2()
{
   int vort;
   double tmpvx,tmpvy,avgrel,avgabs;
   
   avgabs = 0.0;
   avgrel = 0.0;
	
   for (vort=0; vort<N; ++vort)
     {
	dpos_vel(&(mblob[vort].blob0),&(tmpparms[vort]));
	tmpvx = mblob[vort].blob0.dx;
	tmpvy = mblob[vort].blob0.dy;
	
	dpos_vel_fast(vort);
	
	if (SQR(mblob[vort].blob0.x)+SQR(mblob[vort].blob0.y)<SQR(0.25))
	  {
	     printf("%d %12.4e %12.4e\n",
		    vort,
		    sqrt(SQR(tmpvx-mblob[vort].blob0.dx)+
			 SQR(tmpvy-mblob[vort].blob0.dy)),
		    sqrt(SQR(tmpvx-mblob[vort].blob0.dx)+
			 SQR(tmpvy-mblob[vort].blob0.dy))/
		    sqrt(SQR(mblob[vort].blob0.dx)+
			 SQR(mblob[vort].blob0.dy)));
	     avgabs += sqrt(SQR(tmpvx-mblob[vort].blob0.dx)+
			 SQR(tmpvy-mblob[vort].blob0.dy));
	     avgrel += sqrt(SQR(tmpvx-mblob[vort].blob0.dx)+
			    SQR(tmpvy-mblob[vort].blob0.dy))/
	       sqrt(SQR(mblob[vort].blob0.dx)+
		    SQR(mblob[vort].blob0.dy));
	  }
     }
   printf("%12.4e %12.4e\n",avgabs/N,avgrel/N);
   exit(1);
}
   
void read_sim()
{
   char      sim_name[Title],vtxfilename[Title],temp[Title];
   FILE      *sim_file;
   char *word,*p1;
   int  i,inputs_size;
   
   sprintf(sim_name,"%s%s",filename,".sim");
   fprintf(diag_log,"Reading simfile...\n");
   sim_file = fopen(sim_name,"r");
   
   /* ASSUME a 32-bit word. */
   inputs_size = sizeof(inputs)/4;
   word = malloc(100*sizeof(char));
   
   fscanf(sim_file,"%s",word);

   while (!feof(sim_file))
     {
	
	/*Keep this just in case.  On gcc, the memcmp automatically skips
	 * over whitespace.  I am not sure if everyone does this.*/
	while ((isspace(*word)) && (word != '\0'))
	  ++word;
	
	if (*word == '#')
	  {
	     while (*word != '\n')
	       *word = fgetc(sim_file);
	  }
	else	
	  if (*word != '\0')
	  {
	     for (i=0; i<inputs_size; ++i)
	       if (!memcmp(word,inputs[i],strlen(inputs[i])))
	       {
		  switch (i)
		    {
		     case FRAME_STEP:
		       fscanf(sim_file,"%lf",&FrameStep);
		       i=inputs_size+1;
		       break;
		     case END_TIME:  
		       fscanf(sim_file,"%lf",&EndTime);
		       i=inputs_size+1;
		       break;
		     case VISCOSITY:
		       fscanf(sim_file,"%lf",&visc);
		       i=inputs_size+1;
		       break;
		     case VTX_INIT:
		       fscanf(sim_file,"%s",vtxfilename);
		       i=inputs_size+1;
		       break;
		     default:
		       printf("Uh oh.  There is an error in the scripting code.\n");
		    }
	       }
	     if (i==inputs_size)
	       printf("Unrecognized input variable: %s\n",word);
	  }
	fscanf(sim_file,"%s",word);
     }
   fclose(sim_file);
   
   p1 = getenv("ECCSVM_HOME");
   
   if (p1 == NULL) 
     p1 = getenv("PWD");

   sprintf(temp,"%s/%s",p1,vtxfilename);
   
   sim_file = fopen(temp,"r");

   fscanf(sim_file,"%lf%lf%lf%lf%lf%lf",
	  &mblob[0].blob0.x,
	  &mblob[0].blob0.y,
	  &mblob[0].blob0.strength,&blobguts[0].s2,
	  &blobguts[0].a2,&blobguts[0].th);
   
   mblob[0].blob0.order = 1;
   set_blob(&(blobguts[0]),&(tmpparms[0]));

   N = 1;
   
   while (!feof(sim_file))
     {
	fscanf(sim_file,"%lf%lf%lf%lf%lf%lf",
	       &mblob[N].blob0.x,
	       &mblob[N].blob0.y,
	       &mblob[N].blob0.strength,&blobguts[N].s2,
	       &blobguts[N].a2,&blobguts[N].th);
	
	mblob[N].blob0.order = 1;
	set_blob(&(blobguts[N]),&(tmpparms[N]));
	++N;
     }
   --N;
   
   fclose(sim_file);
   
   fprintf(comp_log,"Simulation parameters.\n");
   fprintf(comp_log,"%s %12.4e\n",inputs[FRAME_STEP],FrameStep);
   fprintf(comp_log,"%s %12.4e\n",inputs[END_TIME],EndTime);
   fprintf(comp_log,"%s %12.4e\n",inputs[VISCOSITY],visc);
   fprintf(comp_log,"%s %s\n",inputs[VTX_INIT],vtxfilename);
   fprintf(comp_log,"%d vortices read from %s.\n",N,temp);
   fflush(comp_log);
}

void read_ctl()
{
   FILE *control_file;
   char *word,control_name[Title];
   int  i,inputs_size;

   sprintf(control_name,"%s%s",filename,".ctl");
   
   /* ASSUME a 32-bit word. */
   inputs_size = sizeof(inputs)/4;
   
   word = malloc(100*sizeof(char));

   control_file = fopen(control_name,"r");
   
   fscanf(control_file,"%s",word);

   while (!feof(control_file))
     {
	
	/*Keep this just in case.  On gcc, the memcmp automatically skips
	 * over whitespace.  I am not sure if everyone does this.*/
	while ((isspace(*word)) && (word != '\0'))
	  ++word;
	
	if (*word == '#')
	  {
	     while (*word != '\n')
	       *word = fgetc(control_file);
	  }
	else	
	  if (*word != '\0')
	  {
	     for (i=0; i<inputs_size; ++i)
	       if (!memcmp(word,inputs[i],strlen(inputs[i])))
	       {
		  switch (i)
		    {
		     case TIME_STEP:
		       fscanf(control_file,"%lf",&PrefStep);
		       i=inputs_size+1;
		       break;
		     case L2_TOL:
		       fscanf(control_file,"%lf",&l2tol);
		       i=inputs_size+1;
		       break;
		     case ALPHA:
		       fscanf(control_file,"%lf",&alpha);
		       i=inputs_size+1;
		       break;
		     case MERGE_BUDGET:
		       fscanf(control_file,"%lf",&merge_budget);
		       i=inputs_size+1;
		       break;
		     case CLUSTER_RADIUS:
		       fscanf(control_file,"%lf",&clusterR);
		       i=inputs_size+1;
		       break;
		     case MERGE_STEP:
		       fscanf(control_file,"%lf",&MergeStep);
		       i=inputs_size+1;
		       break;
		     case MERGE_A2_TOL:
		       fscanf(control_file,"%lf",&merge_a2tol);
		       i=inputs_size+1;
		       break;
		     case MERGE_TH_TOL:
		       fscanf(control_file,"%lf",&merge_thtol);
		       i=inputs_size+1;
		       break;
		     default:
		       printf("Uh oh.  There is an error in the scripting code.\n");
		    }
	       }
	     if (i==inputs_size)
	       printf("Unrecognized input variable: %s\n",word);
	  }
	fscanf(control_file,"%s",word);
     }
   fclose(control_file);
   
   fprintf(comp_log,"Approximation control parameters.\n");
   fprintf(comp_log,"%s %12.4e\n",inputs[TIME_STEP],PrefStep);
   fprintf(comp_log,"%s %12.4e\n",inputs[MERGE_STEP],MergeStep);
   fprintf(comp_log,"%s %12.4e\n",inputs[L2_TOL],l2tol);
   fprintf(comp_log,"%s %12.4e\n",inputs[ALPHA],alpha);
   fprintf(comp_log,"%s %12.4e\n",inputs[MERGE_BUDGET],merge_budget);
   fprintf(comp_log,"%s %12.4e\n",inputs[CLUSTER_RADIUS],clusterR);
   fprintf(comp_log,"%s %12.4e\n",inputs[MERGE_A2_TOL],merge_a2tol);
   fprintf(comp_log,"%s %12.4e\n",inputs[MERGE_TH_TOL],merge_thtol);
   fflush(comp_log);
}

void init(int argc, char *argv[]) 
{
   char      sim_name[Title],control_name[Title],temp[Title],*p1;
   int       i;

   dth_regularize = 1.0e-5;
   
   /*Allocate memory for multipole coefficients.*/
   for (i=0; i<LMax; ++i)
     Level_Ptr[i] = 
     malloc(sizeof(complex)*PMax*((int) ldexp(1.0,2*(i+1))));
 
   p1 = getenv("ECCSVM_HOME");
   if (p1 == NULL)
     p1 = getenv("PWD");

   else strcpy(temp,p1);
   
   p1 = getenv("ECCSVM_BASENAME");
   if (p1 == NULL) 
     sprintf(filename,"%s/%s",temp,"dipoles");
   else 
     sprintf(filename,"%s/%s",temp,p1);
   
#ifdef MULTIPROC
   /* set up log files with process number embedded in names */
   sprintf(temp,"%s_comp%d.log",filename, rank);   
   comp_log = fopen(temp,"w");   
   sprintf(temp,"%s_diag%d.log",filename, rank);
   diag_log = fopen(temp,"w");   
   sprintf(temp,"%s_mpi%d.log",filename, rank);
   mpi_log = fopen(temp,"w");   
   trace_log = mpi_log;
#else 
   /*  log file names will NOT have process rank # embedded  */
   sprintf(temp,"%s_comp.log",filename);
   comp_log = fopen(temp,"w");
   sprintf(temp,"%s_diag.log",filename);
   diag_log = fopen(temp,"w");
   trace_log = diag_log;   
#endif

   fprintf(diag_log,"Initializing.\n");
   
   fprintf(comp_log,"ECCSVM base: %s\n",filename);
   
   sprintf(sim_name,"%s%s",filename,".sim");
   sprintf(control_name,"%s%s",filename,".ctl");


   /* Read in the simulation parameters. */
   
   fprintf(diag_log,"Reading simfile...\n");
   read_sim();
   
   fprintf(diag_log,"Reading ctlfile...\n");
   read_ctl();

   fprintf(diag_log,"Finished reading files.\n");
   
   fprintf(diag_log,"Initializing elements...\n");
   
#ifdef XANTISYMM
   /* Double the number of computational elements by reflecting them
    * about the y-axis. */
   fprintf(comp_log,"X anti-symmetry imposed.\n");
   reflect_Y();
#endif 
   
   Create_Hierarchy();
#ifdef CACHERESORT
   cache_resort();
#endif
   
#ifdef MULTIPROC
   fprintf(mpi_log,"Detected %d processes.\n",total_processes);
   if (total_processes == 2)
     {
	fprintf(mpi_log,"Running peer algorithm.\n");
	peer();
     }
   else
     {
	fprintf(mpi_log,"Running master/slave algorithm.\n");
	if (rank == 0) 
	  master();
	else 
	  slave();
	
	finish();
     }
   
   for (i=0; i<CARDINALITY; ++i) 
     { 
	mblob[i].blob1 = mblob[i].blob0;
	mblob[i].blob2 = mblob[i].blob0;
	mblob[i].blob3 = mblob[i].blob0;
	mblob[i].blob4 = mblob[i].blob0;
     }
#else
   /* single processor code */
   for (i=0; i<CARDINALITY; ++i) 
     { 
#ifdef NOFASTMP
	     dpos_vel(&(mblob[i].blob0),&(tmpparms[i]));
#else
	     dpos_vel_fast(i);
#endif
	mblob[i].blob1 = mblob[i].blob0;
	mblob[i].blob2 = mblob[i].blob0;
	mblob[i].blob3 = mblob[i].blob0;
	mblob[i].blob4 = mblob[i].blob0;
     }
#endif  

#ifdef XANTISYMM 
   /* re-adjust */
   N /= 2;
#endif
   
   /*chkvel2();*/
   
   Release_Links(mplevels);

#ifdef MULTIPROC
   /* Have only the 'root' node do the writes */
   MPI_Comm_rank(MPI_COMM_WORLD, &rank);
   if (rank == 0) {   
     write_vorts(0);
     write_partition(0);
   }
#else 
   /* there is only one processor anyway */
   write_vorts(0);
   write_partition(0);
#endif

   Frame = 1;
   MergeFrame=1;
   TimeStep = PrefStep;
   SimTime = 0.0;
   
   nsplit   = 0;
   nmerge   = 0;
   totsplit = 0;
   totmerge = 0;
}

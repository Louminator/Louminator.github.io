/* EVOLVE-MS.C */
/* Copyright (c) 2000 Louis F. Rossi                                    *
 * Elliptical Corrected Core Spreading Vortex Method (ECCSVM) for the   *
 * simulation/approximation of incompressible flows.                    *

 * This program is free software; you can redistribute it and/or modify *
 * it under the terms of the GNU General Public License as published by *
 * the Free Software Foundation; either version 2 of the License, or    *
 * (at your option) any later version.					*

 * This program is distributed in the hope that it will be useful,      *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of       *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *
 * GNU General Public License for more details.                         *

 * You should have received a copy of the GNU General Public License    *
 * along with this program; if not, write to the Free Software          *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 *
 * USA                                                                  *
 *                                                                      *
 * or until 15 January 2001                                             *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Massachusetts Lowell                                   *
 * One University Ave                                                   *
 * Lowell, MA 01854                                                     *
 * 
 * or after 15 January 2001                                             *
 * Louis Rossi                                                          *
 * Department of Mathematical Sciences                                  *
 * University of Delaware                                               *
 * Newark, DE 19715-2553                                                */

#include "global.h"

#ifdef MULTIPROC
#include "multiproc.h"
#endif

#ifdef XANTISYMM
#define CARDINALITY  N/2
#else
#define CARDINALITY  N
#endif

/* Global variables */

FILE *comp_log,*diag_log,*mpi_log,*trace_log;

int N,oldN;
metablob mblob[NMax];
blob_internal blobguts[NMax];
double visc;
double alpha,l2tol,dth_regularize;
double TimeStep,PrefStep,FrameStep,EndTime,SimTime;
int       Frame;
double merge_budget,merge_p,merge_a2tol,merge_thtol,clusterR,MergeStep;
int       nsplit,nmerge,totmerge,totsplit,MergeFrame;
char      filename[Title];

blobparms tmpparms[NMax];

/*Fast multipole variables*/

double minX,maxX,minY,maxY,distX,distY;

complex *Level_Ptr[LMax];

int gridx[LMax][NMax], gridy[LMax][NMax], mplevels;

double aM2;

FineGridLink **FineGridLinks,*trace;

/* Subroutine to stop everything if there is a problem. */
void stop(int retval)
{
   fflush(comp_log);
   fflush(diag_log);
   fflush(mpi_log);
   
#ifdef MULTPROC
   Cleanup_mpi();
#endif
   
   exit(retval);
}

void run()
{
   int j,k;
   clock_t cputime,cputime_old;
   char time_name[Title];
   FILE *time_file,*fopen();
   double lambdaM,temp;
 
   fprintf(comp_log,"Time     N     Split Merge MPlev a2M\n");
#ifdef MULTIPROC
   sprintf(time_name,"%s.%d.%s", filename, rank ,"cpu");
#else
   sprintf(time_name,"%s.%s", filename,"cpu");
#endif
   time_file = fopen(time_name,"w");
   cputime=cputime_old=0;
   
   while (SimTime < EndTime)
     {
	cputime_old = cputime;
	cputime = clock();
	fprintf(time_file,"%d %d\n",N,(int)(cputime-cputime_old));
	fflush(time_file);
	
	lambdaM = 0.0;

	nsplit = 0;
	nmerge = 0;
	
	oldN = N;
	
	/* All computational elements march forward. */
	for (j=0; j<N; ++j)
	  {
	     rk4internal(&(blobguts[j]),&(tmpparms[j]),TimeStep);
	     
	     push(&mblob[j]);
	     
	     if (mblob[j].blob0.order == 1)
	       {
		  push(&mblob[j]);
		  ab2(&mblob[j],&tmpparms[j],TimeStep);
	       }
	     
	     if (mblob[j].blob0.order == 2)
	       ab2(&mblob[j],&tmpparms[j],TimeStep);
	     
	     if (mblob[j].blob0.order == 3)
	       ab3(&mblob[j],&tmpparms[j],TimeStep);
	     
	     if (mblob[j].blob0.order == 4)
	       ab4(&mblob[j],TimeStep);
	     
	     if (mblob[j].blob0.order < 3)
	       ++mblob[j].blob0.order;
	     
	     if (blobguts[j].a2 < 0.0)
	       {
		  fprintf(diag_log,
			  "WARNING: Negative a2 in element %d\n",j);
		  for (k=0; k<N; ++k)
		    fprintf(diag_log,
			    "str=%10.3e x=%10.3e y=%10.3e s2=%10.3e a2=%10.3e\n",
			    mblob[k].blob0.strength,
			    mblob[k].blob0.x,mblob[k].blob0.y,
			    blobguts[k].s2,blobguts[k].a2);
		  exit(0); 
	       }	     
	  }
	
	/* Split horizontally challenged elements. */
	chksplit();
	
	/* Set commonly used parameters here. Beyond this point, if any  *
	 * subroutine messes with computational elements, it should also *
	 * reset the parameters.                                         */
	for (j=0; j<N; ++j)
	  {
	     set_blob(&(blobguts[j]),&(tmpparms[j]));
	     /* For diagnostic purposes, calculate lambdaM to advise on
	      * maximum theoretical elongations. */
	     temp = tmpparms[j].du11*(tmpparms[j].cos2-tmpparms[j].sin2)+
	       (tmpparms[j].du12-tmpparms[j].du21)*tmpparms[j].sincos;
	     if (lambdaM<fabs(temp)) 
	       lambdaM = fabs(temp);
	  }
	
	SimTime += TimeStep;
	
	if ((SimTime+0.499*TimeStep) >= MergeStep*MergeFrame)
	  {
	     mplevels = Set_Level();
	     
	     partition(mplevels);
	     
	     merge();
	     resort();
	     
	     Release_Links(mplevels);
	     
	     ++MergeFrame;
	  }
	
	if ((SimTime+0.499*TimeStep) >= FrameStep*Frame)
	  {
#ifdef MULTIPROC
	     /* Have only the 'root' node do the writes */
	     MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	     if (rank == 0) {
	       write_vorts(Frame);
	       write_partition(Frame);
	     }
#else 
	     /* single processor */
	     write_vorts(Frame);
	     write_partition(Frame);	    
#endif

	     ++Frame; 

	     fprintf(comp_log,"%8.2e %-5d %-5d %-5d %-5d %8.2e\n",
		    SimTime,N,totsplit+nsplit,totmerge+nmerge,
		     mplevels,
		     2.0*lambdaM*l2tol/visc+
		     sqrt(1.0+4.0*SQR(lambdaM*l2tol/visc)));
	     fflush(comp_log);
	     fflush(diag_log);
	     fflush(mpi_log);
	  }
	
#ifdef XANTISYMM
	/* Double the number of computational elements by reflecting them
	 * about the y-axis. */
	reflect_Y();
#endif 

	Create_Hierarchy();

#ifdef CACHERESORT
	cache_resort();
#endif

	for (j=0; j<N; ++j)
	  set_blob(&(blobguts[j]),&(tmpparms[j]));

#ifdef MULTIPROC  
	if (total_processes == 2)
	  peer();
	else
	  {
	     if (rank == 0) 
	       master();
	     else 
	       slave();
	     
	     finish();
	  }
#else
	/* single processor code */
	for (j=0; j<CARDINALITY; ++j) 
	  { 
#ifdef NOFASTMP
	     dpos_vel(&(mblob[j].blob0),&(tmpparms[j]));
#else
	     dpos_vel_fast(j);
#endif
	  }
#endif  

#ifdef XANTISYMM 
	/* re-adjust */
	N /= 2;
#endif
	
	totsplit += nsplit;
	totmerge += nmerge;
	Release_Links(mplevels);
     }  /*   end while loop  */

   fprintf(comp_log,"Simulation complete.\n");
   fprintf(comp_log,"Total splitting events: %d\n",totsplit);
   fprintf(comp_log,"Total merging events: %d\n",totmerge);
   fclose(time_file);
}



#ifdef MULTIPROC
int main(int argc, char* argv[])
{
   double starttime, endtime;
   
   Setup_mpi(argc, argv);
   init(argc, argv);
   
   starttime = MPI_Wtime();   
   
   fprintf(diag_log,"Running.\n");
   run();
   
   fclose(comp_log);
   fclose(diag_log);
   endtime = MPI_Wtime();
   fclose(mpi_log);
   Cleanup_mpi();
   
   return(1); 
}

#else

int main(int argc, char* argv[])
{
   init(argc, argv);
   fprintf(diag_log,"Running.\n");
   run();
   
   fclose(comp_log);
   fclose(diag_log);

   return(1); 
}
#endif

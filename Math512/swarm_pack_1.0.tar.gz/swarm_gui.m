function varargout = swarm_gui(varargin)
% SWARM_GUI M-file for swarm_gui.fig
%      SWARM_GUI, by itself, creates a new SWARM_GUI or raises the existing
%      singleton*.
%
%      H = SWARM_GUI returns the handle to a new SWARM_GUI or the handle to
%      the existing singleton*.
%
%      SWARM_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SWARM_GUI.M with the given input arguments.
%
%      SWARM_GUI('Property','Value',...) creates a new SWARM_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before swarm_gui_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to swarm_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help swarm_gui

% Last Modified by GUIDE v2.5 06-Jun-2006 15:25:00

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @swarm_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @swarm_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before swarm_gui is made visible.
function swarm_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to swarm_gui (see VARARGIN)

% Choose default command line output for swarm_gui
handles.output = hObject;
[handles.pos,handles.d] = reset_swarm();
handles.reset = 0;
handles.limit = 5;
handles.zor   = 1;
handles.zoo   = 15;
handles.zoa   = 15;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes swarm_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);

quiver3(handles.pos(1,:),handles.pos(2,:),handles.pos(3,:), ...
    handles.d(1,:),handles.d(2,:),handles.d(3,:));
xlim([-handles.limit,handles.limit]);
ylim([-handles.limit,handles.limit]);
zlim([-handles.limit,handles.limit]);
drawnow;

% --- Outputs from this function are returned to the command line.
function varargout = swarm_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Play.
function Play_Callback(hObject, eventdata, handles)
% hObject    handle to Play (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Play

if (get(hObject,'Value') == get(hObject,'Min'))
    set(hObject,'String','Play');
else
     set(hObject,'String','Pause');
end
pos = handles.pos;
d = handles.d;
while (get(hObject,'Value') == get(hObject,'Max'))
    handles = guidata(hObject);
    if (handles.reset)
        handles.reset = 0;
        pos = handles.pos;
        d = handles.d;
        guidata(hObject,handles);
    end
    [pos,d] = step(pos,d,handles.zor,handles.zoo,handles.zoa);
    quiver3(pos(1,:),pos(2,:),pos(3,:),d(1,:),d(2,:),d(3,:));
    xlim([-handles.limit,handles.limit]);
    ylim([-handles.limit,handles.limit]);
    zlim([-handles.limit,handles.limit]);
    drawnow;
end
handles.pos = pos;
handles.d   = d;
guidata(hObject, handles);

% --- Executes on button press in Reset.
function Reset_Callback(hObject, eventdata, handles)
% hObject    handle to Reset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[handles.pos,handles.d] = reset_swarm();
quiver3(handles.pos(1,:),handles.pos(2,:),handles.pos(3,:),...
    handles.d(1,:),handles.d(2,:),handles.d(3,:));
xlim([-handles.limit,handles.limit]);
ylim([-handles.limit,handles.limit]);
zlim([-handles.limit,handles.limit]);
drawnow;
handles.reset = 1;
guidata(hObject, handles);

% --- Executes on slider movement.
function zoa_Callback(hObject, eventdata, handles)
% hObject    handle to zoa (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

handles.zoa = get(hObject,'Value');
guidata(hObject,handles);
set(handles.zoa_value,'String',['ZOA: ' num2str(handles.zoa)]);

% --- Executes during object creation, after setting all properties.
function zoa_CreateFcn(hObject, eventdata, handles)
% hObject    handle to zoa (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes during object creation, after setting all properties.
function zoa_value_CreateFcn(hObject, eventdata, handles)
% hObject    handle to zoa_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

set(hObject,'Value',15);

% --- Executes on slider movement.
function zoo_Callback(hObject, eventdata, handles)
% hObject    handle to zoo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
handles.zoo = get(hObject,'Value');
guidata(hObject,handles);
set(handles.zoo_value,'String',['ZOO: ' num2str(handles.zoo)]);


% --- Executes during object creation, after setting all properties.
function zoo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to zoo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

set(hObject,'Value',15);


% --- Executes on slider movement.
function zor_Callback(hObject, eventdata, handles)
% hObject    handle to zor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
handles.zor = get(hObject,'Value');
guidata(hObject,handles);
set(handles.zor_value,'String',['ZOR: ' num2str(handles.zor)]);


% --- Executes during object creation, after setting all properties.
function zor_CreateFcn(hObject, eventdata, handles)
% hObject    handle to zor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

set(hObject,'Value',1);


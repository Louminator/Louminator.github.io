function d = velocity(pos,d,zor_in,zoo_in,zoa_in)

[tmp,N] = size(pos);

zor = zor_in;
zoo = zor + zoo_in;
zoa = zoo + zoa_in;
repulse_ang = cos(100*pi/180);

r = zeros(3,N,N);
nr = zeros(N,N);
dots = zeros(N,N);

for j = 1:N
    for k = j:N
        r(:,j,k) = pos(:,k) - pos(:,j);
        r(:,k,j) = -r(:,j,k);
        nr(j,k) = norm(r(:,j,k));
        nr(k,j) = nr(j,k);
        dots(j,k) = r(:,j,k)'*d(:,j);
        dots(k,j) = -dots(j,k);
    end
end

dr = zeros(3,N);
do = zeros(3,N);
da = zeros(3,N);
nd = zeros(3,N);

for j=1:N
    
    zor_k = find(nr(j,:) > 0  & nr(j,:) <= zor & ...
        dots(j,:) - repulse_ang*nr(j,:) >= 0);
    zoo_k = find(nr(j,:) > zor & nr(j,:) <= zoo);
    zoa_k = find(nr(j,:) > zoo & nr(j,:) <= zoa);
    
    if (length(zor_k)>0)
        for k=zor_k
            dr(:,j) = dr(:,j) - r(:,j,k)/nr(k,j);
        end
        nd(:,j) = dr(:,j)/norm(dr(:,j)); 
    else
        for k=zoo_k
            do(:,j) = do(:,j) + d(:,k)/norm(d(:,k));
        end
        for k=zoa_k
            da(:,j) = da(:,j) + r(:,j,k)/nr(k,j);
        end
        if (length(zoa_k) == 0)
            nd(:,j) = do(:,j);
        elseif (length(zoo_k) == 0)
            nd(:,j) = da(:,j);
        else
            nd(:,j) = 0.5*(do(:,j)/norm(do(:,j))+da(:,j)/norm(da(:,j)));
        end
        if (norm(nd(:,j)) == 0)
            nd(:,j) = d(:,j);
        end
    end
    
    nd(:,j) = nd(:,j)/norm(nd(:,j));
end

d = nd;

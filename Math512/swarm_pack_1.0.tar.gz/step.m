function [pos,d] = step(pos,d,zor_in,zoo_in,zoa_in)

% A very simple integrator.

s=0.1;

d = velocity(pos,d,zor_in,zoo_in,zoa_in);
pos = pos + s*d;

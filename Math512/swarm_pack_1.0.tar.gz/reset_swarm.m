function [pos,d] = reset_swarm()

rand('state', sum(100*clock));

N = 100;

pos = zeros(3,N);
d   = zeros(3,N);

for j=1:N
    pos(:,j) = N^(1/3)*2*(rand(3,1)-0.5);
    
    th = 2*pi*rand; 
    phi = pi*rand;    
    d(1,j) = cos(th)*sin(phi);
    d(2,j) = sin(th)*sin(phi);
    d(3,j) = cos(phi);
end
